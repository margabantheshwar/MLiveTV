

import { Channel, CategoryItem, AppSettings, PromoItem } from './types';

export const STORAGE_KEY = 'live_tv_channels_v5';
export const CATEGORIES_KEY = 'live_tv_categories_v1';
export const NOTIFICATIONS_KEY = 'live_tv_notifications_v1';
export const PROMOS_KEY = 'live_tv_promos_v1';
export const SETTINGS_KEY = 'live_tv_settings_v1';
export const FAVORITES_KEY = 'live_tv_favorites_v1';
export const HISTORY_KEY = 'live_tv_history_v1';

export const DATA_VERSION = 1764849000000; // Incrementing this forces an update

export const ADMIN_PASSWORD = 'MargabantheshwaR@04102003@'; 
export const ADSENSE_CLIENT_ID = 'ca-pub-0000000000000000'; // Replace with ID

export const DEFAULT_SETTINGS: AppSettings = {
  "aboutContent": "The content on MLiveTV (the “Website”) is provided for informational and entertainment purposes only.\n\nMLiveTV does not stream or host any channels directly. All live TV channels and streams featured on our platform are publicly available on the internet and are aggregated from third-party sources.\n\nWe do not own, control, or claim any rights to the content provided.",
  "shareTitle": "MLiveTV",
  "shareText": "Watch Live TV Channels on MLiveTV!",
  "shareUrl": "https://mlivetv.netlify.app/",
  "enableAds": false
};

export const DEFAULT_CATEGORIES: CategoryItem[] = [
  {
    "id": "all",
    "label": "All Channels",
    "isSystem": true
  },
  {
    "id": "tamil",
    "label": "Tamil"
  },
  {
    "id": "news",
    "label": "News"
  },
  {
    "id": "sports",
    "label": "Sports"
  },
  {
    "id": "movie",
    "label": "Movies Download"
  },
  {
    "id": "kids",
    "label": "Kids"
  },
  {
    "id": "music",
    "label": "Music"
  },
  {
    "id": "international",
    "label": "International"
  },
  {
    "id": "devotional",
    "label": "Devotional"
  },
  {
    "id": "tamil-local-channel",
    "label": "Tamil Local Channel"
  }
];

export const DEFAULT_PROMOS: PromoItem[] = [];

export const DEFAULT_CHANNELS: Channel[] = [
  {
    "id": "afdf9c69-a6b4-43c5-a84e-276530956ab0",
    "name": "Mojo",
    "logo": "https://media.licdn.com/dms/image/v2/C510BAQFvx5iferruLQ/company-logo_200_200/company-logo_200_200/0/1631369744240?e=2147483647&v=beta&t=c1vRJBIDf7VPSoqikFx_hq-32nk037NjkwU3E2nSPzo",
    "link": "https://watchmojo-1-us.rewardedtv.wurl.tv/2000.m3u8",
    "category": "international",
    "streamType": "hls",
    "createdAt": 1764430649432
  },
  {
    "id": "c2638e42-6ca0-46b4-b793-d81f0efb5852",
    "name": "Murasu",
    "logo": "https://d229kpbsb5jevy.cloudfront.net/yuppfast/content/common/channel/logos/murasu.png",
    "link": "https://segment.yuppcdn.net/050522/murasu/050522/murasu_1800/chunks.m3u8",
    "category": "tamil",
    "createdAt": 1764430984397
  },
  {
    "id": "3bfd4f65-5bd7-4527-b78d-750d5095bf5b",
    "name": "Peppers ",
    "logo": "https://d229kpbsb5jevy.cloudfront.net/yuppfast/content/common/channel/logos/peppers-tv.png",
    "link": "https://yuppftalive.akamaized.net/080823/pepperstv/hdntl=exp=1764517413~acl=%2f*~data=hdntl~hmac=5bffbd79df8b0e586141248139022af63b2d777b75165517c8dcf6990d27a45c/chunks.m3u8?ads.app_bundle&ads.app_store_url&ads.channel=6644&ads.channel_name=PeppersTV&ads.content_custom_1_param=FAST&ads.content_custom_3_param=YuppFastIndia&ads.content_genre=ENTERTAINMENT&ads.content_livestream=1&ads.language=TAM&ads.network_name=yuppfast&ads.user=2",
    "category": "tamil",
    "createdAt": 1764431054721
  },
  {
    "id": "199f27a2-5e8e-44a4-b7a5-25ae05c9bc53",
    "name": "Polimer News",
    "logo": "https://d229kpbsb5jevy.cloudfront.net/yuppfast/content/common/channel/logos/polimer-news.png",
    "link": "https://yuppnimresmum.akamaized.net/110322/polimernews/110322/polimernews_1800/hdntl=exp=1764727782~acl=%2f*~data=hdntl~hmac=6f79f67cec6f9a58306b3635c4a4576f599d76d34306147ee83c4810cfb8b941/chunks.m3u8",
    "backupLink": "https://www.youtube.com/watch?v=Ei6NUWLQCQM",
    "category": "news",
    "createdAt": 1764431114414
  },
  {
    "id": "8d3aa9ec-421c-4ed2-9c42-06fc24398533",
    "name": "Puthiya Thalaimurai",
    "logo": "https://d229kpbsb5jevy.cloudfront.net/yuppfast/content/common/channel/logos/puthiya-thalaimurai.png",
    "link": "https://yuppnimresmum.akamaized.net/240122/puthiya/240122/puthiya_1800/hdntl=exp=1764840010~acl=%2f*~data=hdntl~hmac=dd177f6ec47f1eae16c89741af86487ea8c09d0f4d5711ce4b109b5fe231168a/chunks.m3u8",
    "category": "news",
    "createdAt": 1764431198239
  },
  {
    "id": "12223d32-acde-46af-9679-cba0722d61e4",
    "name": "Seithigal TV",
    "logo": "https://d229kpbsb5jevy.cloudfront.net/yuppfast/content/common/channel/logos/seithigal-tv.png",
    "link": "https://yuppnimresmum.akamaized.net/120723/smil:seithagal.smil/hdntl=exp=1764839716~acl=%2f*~data=hdntl~hmac=fa94fe93b25b20fa429816a757b6705b48fdd31c7117a73f982d56f657cca8ae/chunklist_b696000.m3u8",
    "category": "news",
    "createdAt": 1764431314524
  },
  {
    "id": "b6e831ef-e1d1-44a4-b3e1-5268ed9c4614",
    "name": "Tamil Yogi",
    "logo": "https://images.sftcdn.net/images/t_app-cover-s,f_auto/p/6485adf9-00a7-44d1-bea9-0af2c882dfc6/1195918546/tamil-yogi-0y8-screenshot",
    "link": "https://1tamilyogi.meme/",
    "category": "movie",
    "createdAt": 1764433106121
  },
  {
    "id": "d02bbdc0-c2ef-4dcc-9fbc-f61239f4470d",
    "name": "News7 Tamil",
    "logo": "https://d229kpbsb5jevy.cloudfront.net/tv/150/150/bnw/news7tamil-black.png",
    "link": "https://segment.yuppcdn.net/240122/news7/240122/news7_1800/chunks.m3u8",
    "category": "news",
    "createdAt": 1764433309242
  },
  {
    "id": "899a68b0-ceec-401e-a805-772ce0b98016",
    "name": "F1 TV",
    "logo": "https://images.seeklogo.com/logo-png/33/2/formula-1-logo-png_seeklogo-330361.png",
    "link": "https://amg12058-amg12058c1-vidaa-us-8693.playouts.now.amagi.tv/playlist/amg12058-c15medianetworkslimitedfast-formula1tv-vidaaus/playlist.m3u8",
    "category": "sports",
    "createdAt": 1764433496543,
    "streamType": "auto"
  },
  {
    "id": "0d411a57-1c2a-4ecc-be6c-c34fbdf07507",
    "name": "Popcorn Flix",
    "logo": "https://image.roku.com/developer_channels/prod/b54f776fe989512130e4c758829cd80cb5ff65ca81ac1f0ce6fb0c6f24577880.png",
    "link": "https://d1j2u714xk898n.cloudfront.net/scheduler/scheduleMaster/145/variant/22099474.m3u8",
    "category": "international",
    "streamType": "hls",
    "createdAt": 1764488577197
  },
  {
    "id": "mill3j93qxqrfgzhs",
    "name": "Willow",
    "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSikdk313Ay8M5RT8udR04GWvD9yW8aAfpDLw&s",
    "link": "https://fl1.moveonjoy.com/WILLOW_CRICKET/tracks-v1a1/mono.m3u8",
    "category": "sports",
    "streamType": "hls",
    "createdAt": 1764498918711
  },
  {
    "id": "milmwterbpkv2rpic",
    "name": "Hollywood Movies",
    "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSSWvu89q5NlWGlnhuX5ZIHXQ7Kgtk6znYs-w&s",
    "link": "https://movies.nexg.tv/movie-h/movie-h.smil/chunklist_w1663714018_b1708000_t64SElHSA==.m3u8",
    "category": "international",
    "streamType": "hls",
    "createdAt": 1764501964515
  },
  {
    "id": "milmztre3u88cersu",
    "name": "Universal Action",
    "logo": "https://image.xumo.com/v1/channels/channel/99951254/600x337.webp?type=channelTile",
    "link": "https://d4whmvwm0rdvi.cloudfront.net/manifest/3fec3e5cac39a52b2132f9c66c83dae043dc17d4/prod_default_xumo-nbcu-linear/6063fe38-de37-4d8a-9bea-7c37b6b5f4e0/0.m3u8",
    "category": "international",
    "streamType": "hls",
    "createdAt": 1764502104938
  },
  {
    "id": "miln3ro04o7pd5jhp",
    "name": "Xumo Sci Fi & Fantasy",
    "logo": "https://image.xumo.com/v1/channels/channel/99991362/600x337.webp?type=channelTile",
    "link": "https://d3fmqi91qduj7.cloudfront.net/manifest/3fec3e5cac39a52b2132f9c66c83dae043dc17d4/prod_default_tcl-2/8ebba123-9c8a-4266-95c5-019d326d1983/0.m3u8",
    "category": "international",
    "streamType": "hls",
    "createdAt": 1764502288848
  },
  {
    "id": "miln6h43uc7wbaqw0",
    "name": "At The Movies",
    "logo": "https://image-resizer-cloud-cdn.api.cms.amdvids.com/image/D2DC3D4D-2ACF-475A-A254-0016D18F3BF0/3-1x1.png/900",
    "link": "https://amg00136-wbd-amg00136c3-tablo-us-7099.playouts.now.amagi.tv/playlist480P.m3u8",
    "category": "international",
    "streamType": "hls",
    "createdAt": 1764502415139
  },
  {
    "id": "milndvahi1y8571vt",
    "name": "Crime Flix",
    "logo": "https://img.static-ottera.com/prod/mom/linear_channel/thumbnails/square/crimeflix_logo_1-1_2.png",
    "link": "https://dgx2snzx175pa.cloudfront.net/scheduler/scheduleMaster/391/variant/22099982/3a3aee5e-01a5-4568-80a4-dce8d5aee8c1.m3u8",
    "category": "international",
    "streamType": "hls",
    "createdAt": 1764502760105
  },
  {
    "id": "milngno6cbjb4ocje",
    "name": "Sony Movies",
    "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9b/Sony_Movies_Logo.svg/2042px-Sony_Movies_Logo.svg.png",
    "link": "https://a-cdn.klowdtv.com/live1/smc_720p/chunks.m3u8",
    "category": "international",
    "streamType": "hls",
    "createdAt": 1764502890198
  },
  {
    "id": "milnp6f7tq87sbez0",
    "name": "Star Movies ",
    "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/5/54/STAR_Movies_logo.svg/1200px-STAR_Movies_logo.svg.png",
    "link": "https://webtvstream.bhtelecom.ba/hls18/star_movies_1200.m3u8",
    "category": "international",
    "streamType": "hls",
    "createdAt": 1764503287747
  },
  {
    "id": "milnrqd6fhhqopteq",
    "name": "Screambox Tv",
    "logo": "https://www.allhallowsgeek.com/wp-content/uploads/2023/09/screambox.jpg",
    "link": "https://wurlcineverse.global.transmit.live/hls/6788648b58870f59fceabf97/v1/cinedigm_entertainment_corp_screamboxtv_1/lg_us/latest/main/hls/playlist.m3u8?wurl_channel=1845&wurl_name=ScreamboxTV",
    "category": "international",
    "streamType": "hls",
    "createdAt": 1764503406906
  },
  {
    "id": "milnwj6xw863ddzlj",
    "name": "Flimrise Anime",
    "logo": "https://image.roku.com/developer_channels/prod/1455341b423d13d644edde109522e423732367a2169f552322aa14a614e2654d.png",
    "link": "https://d3f4oii5n0oeqi.cloudfront.net/manifest/3fec3e5cac39a52b2132f9c66c83dae043dc17d4/prod_default_tcl-ams-aws/e8325aad-5cc8-423c-a90a-7e86fd5ef98d/0.m3u8",
    "category": "kids",
    "streamType": "hls",
    "createdAt": 1764503630889
  },
  {
    "id": "milo0079jku44g0jc",
    "name": "Aennis & Gnasher ",
    "logo": "https://m.media-amazon.com/images/M/MV5BYjQzMGNiYzgtOTdkYi00ODVjLTlkZDgtNjljOWM4M2YxNTZjXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg",
    "link": "https://d1upcw8nab85tc.cloudfront.net/v1/manifest/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-6yrujqvjvg52l/4ea12ac9-2928-4309-9102-8c75be927dda/2.m3u8",
    "category": "kids",
    "streamType": "hls",
    "createdAt": 1764503792901
  },
  {
    "id": "milo2qn4etfmqp6fn",
    "name": "Hotwheels Action",
    "logo": "https://yt3.googleusercontent.com/1LXOgGyitCoXAwodOD7gA6pr3HigED17qRjgMEiMbQHzw6gK7TNtlWGkxnPABPcleW020phnqA=s900-c-k-c0x00ffffff-no-rj",
    "link": "https://dtz4aepbew7ez.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-j02089jh4uhwc/hotwh.m3u8",
    "category": "kids",
    "streamType": "hls",
    "createdAt": 1764503920480
  },
  {
    "id": "milo4w826m0lvjx80",
    "name": "Bob & Builder ",
    "logo": "https://upload.wikimedia.org/wikipedia/en/thumb/c/c6/Bob_the_Builder_logo.svg/1200px-Bob_the_Builder_logo.svg.png",
    "link": "https://d3fzp5pjpdrsrt.cloudfront.net/v1/manifest/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-ud9wnx2egsqsf/c1f2c189-24ac-4002-9171-c12095e0226e/0.m3u8",
    "category": "kids",
    "streamType": "hls",
    "createdAt": 1764504021026
  },
  {
    "id": "milo798l5o6ojsnlx",
    "name": "Doreamon",
    "logo": "https://e7.pngegg.com/pngimages/329/299/png-clipart-doraemon-character-youtube-television-channel-doraemon-doraemon-television-cartoon.png",
    "link": "https://live20.bozztv.com/giatvplayout7/giatv-209902/tracks-v1a1/mono.ts.m3u8",
    "category": "kids",
    "streamType": "hls",
    "createdAt": 1764504131205
  },
  {
    "id": "milo969ldz41owsxg",
    "name": "Motu Patlu",
    "logo": "https://m.media-amazon.com/images/I/511ljmZFEgS._AC_UF350,350_QL80_.jpg",
    "link": "https://live20.bozztv.com/giatvplayout7/giatv-209622/tracks-v1a1/mono.ts.m3u8",
    "category": "kids",
    "streamType": "hls",
    "createdAt": 1764504220665
  },
  {
    "id": "milocmu845mqse9e4",
    "name": "Sonic The Hedgehog",
    "logo": "https://upload.wikimedia.org/wikipedia/commons/9/91/Sonic_the_Hedgehog_1991_logo.webp",
    "link": "https://d3fmqi91qduj7.cloudfront.net/manifest/3fec3e5cac39a52b2132f9c66c83dae043dc17d4/prod_default_tcl-2/0b2ae741-2d49-483e-89dc-2ab13aecc75a/0.m3u8",
    "category": "kids",
    "streamType": "hls",
    "createdAt": 1764504382112
  },
  {
    "id": "milof93hrlxrm2rcd",
    "name": "Mr Bean",
    "logo": "https://e7.pngegg.com/pngimages/618/786/png-clipart-video-youtube-animated-cartoon-animated-series-mr-bean-dance.png",
    "link": "https://amg00627-banijay-amg00627c28-lg-gb-4244.playouts.now.amagi.tv/ts-eu-w1-n2/playlist/amg00627-banijayfast-mrbeanukcc-lggb/cb563d1b7c6c608f84c33d78d6f36217ea7b3dcb0e6c886470af4a9765d94639dde3af96e65b9c08398f46be395533044d18a809df746ec2ce26f10a616c6a25c988cd18c9f10b19c3984f767fd42f4c2aa74a0ad625563c88a74b5dc5759e51313ec4452e5a3b86b849da23019edf139b197cc9ee843e67625b5781584d98ff0cfaa3b44244dd19a0b51458f67e13b6c01bd6d21cbf9ed5498a428f22f410c893f3968044d7838c62a801b279515b767cd4d77cc0cd0db28cca3b38cc75723d743ee7a780b04f2c96494251fd8da7d50fc432feb91aaf411a9e3dc20eee5e8b6fb947a3e458a9aebecb5b513cd6ab310c1c84c096a3d8100c895fcb87d4870b16f4f7106b09cd62d62d3f2b95f1c766e3a970ad920db689336952a8904188d3b587ffa2ff22f643f1e0d0a80f7f141c6e6f8759b1d478c839cf71becf10382e232ec1a160f7b9e96c19546ea5b9638e5071d6da8f90910f2bda730f55fa65cc49091ebc5e0247c41dc9a50f58a6142fb00711c60274ea2cfdbc3fbba6cbf5103ea7cdce4df11d80df67e9d73299520a7c3080db037178160fba8967092337ca43e5a1ad8b123229cad6f0a4833957063d041c088ef4ee739e83cf2d181ab3234c0e4f3432a02df54ce02d66240be52389dc631284023263efb74d3b3008ade181bcdd97a02ab47bc081f93c39325a66b0320e231cbcdce062d91d7d575978bf224568983a003f80f9c8e18ace6acb8a6da93d6b1011a89a7c7a2d77454a29beaf41f363b8e377df9ace4f82fa8c6023ef58983431a38aa70693ec85d4010696ab43007792a14baf1916ee31f514bceb40fd8d0f457653414cd1c053fb4fabdc95c9389f22b93d731484439cb8d381e94579c9a26f1d07340f69153e77281ff6d8c06a0477e9b52394338c876e8872640c1d72f0a62c7bbbb20576fb347a73ebacca9fdfad6975f142d941f43a79cc3c0c2af2823be596bce7e89e1d3f6ab08d88638e8fbcb3f5eb906214676d34888f4b5465df23e48d0393d9770ed4bdaad7fd4ba354c60a9aa89a01d31984f68e18c4fff568245a6d3c7379bea4def410d2bd782ad119fa7e5dd31817868e01dac9b5060287350f722a1cc91d7658c7a5fa0d8a5fd00b940695e55d77af1e06c0edf62a5ce625a33578159babd73e6b9f935bc10ef33d967eb81a6e211ceb1741d5f27127e62a01d59c596c70fe0206c35c8bc4d25d4d73944f074fcd6c211a13d84c502dab6b24f55afaedd2b9672e8b5aca2c0f8a39a6f25fa8ac09aedcf7b3ffbd0730e7fb051df74fca0aba63e1eacfc071e47271ba64942d67a4f4d5ea87ba97e2818e500b4dd60cb021fc5bb68ae99d7c0d0f3af90a384127b55df50e1b409dcb5b85f61522d39ed00cc10f58404d4565ea48eac4557b442588f474d28b3a36273d4283a965be3c87376fd50f48e8602b787a264251ae92bf7eff39cc7bb48e3f09d58db8ac23a5c012d19e8feabf0938ca5d284b42f8e46ff05fc7e555f20617830792ca49aa88e3d6f2ba54d7bb/3/640x360_1057680/index.m3u8",
    "category": "kids",
    "streamType": "hls",
    "createdAt": 1764504504269
  },
  {
    "id": "milohw9lum159rzn0",
    "name": "Green Gold Tv",
    "logo": "https://i0.wp.com/pinkcity.com/wp-content/uploads/2014/02/hqdefault.jpg?fit=480%2C360&ssl=1",
    "link": "https://vglivessai.akamaized.net/ptnr-yupptv/title-Green_Gold_India/eu/v1/manifest/611d79b11b77e2f571934fd80ca1413453772ac7/675a37e5-f517-434e-adae-d25ae1706340/f69e572a-4efc-49c3-9c4b-3a78e8dda061/3.m3u8",
    "category": "kids",
    "streamType": "hls",
    "createdAt": 1764504627609
  },
  {
    "id": "milop023o8e4xu7p0",
    "name": "Isaiaruvi ",
    "logo": "https://d229kpbsb5jevy.cloudfront.net/bott/content/channels/tvguide/isai-1708094091902.png",
    "link": "https://segment.yuppcdn.net/140622/isaiaruvi/140622/isaiaruvi_1800/chunks.m3u8",
    "category": "music",
    "streamType": "hls",
    "createdAt": 1764504959115
  },
  {
    "id": "milopj6likv83aff1",
    "name": "Isaiaruvi ",
    "logo": "https://d229kpbsb5jevy.cloudfront.net/bott/content/channels/tvguide/isai-1708094091902.png",
    "link": "https://segment.yuppcdn.net/140622/isaiaruvi/140622/isaiaruvi_1800/chunks.m3u8",
    "category": "tamil",
    "streamType": "hls",
    "createdAt": 1764504983901
  },
  {
    "id": "miloykx6mkr9c4xq8",
    "name": "History Tv 18 HD-English",
    "logo": "https://static.wikia.nocookie.net/logopedia/images/0/0d/History_TV18.jpg/revision/latest?cb=20171207202924",
    "link": "https://amg01448-amg01448c15-samsung-in-3494.playouts.now.amagi.tv/playlist/amg01448-samsungindia-historychannelenglish-samsungin/playlist.m3u8",
    "category": "international",
    "streamType": "hls",
    "createdAt": 1764505406058
  },
  {
    "id": "milq2ph20nbpgk4m2",
    "name": "Wild Flix",
    "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQPIdWZ_pOQcrNnQqfhSJZB7mh6UJPXTWxQ_A&s",
    "link": "https://cc-qgrxgp51645lw.akamaized.net/v1/manifest/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-qgrxgp51645lw/9e7dbd77-8e25-4ff1-839a-8c92dfb807b4/2.m3u8",
    "category": "international",
    "streamType": "hls",
    "createdAt": 1764507278198
  },
  {
    "id": "milq5tcgq0urko2l3",
    "name": "BBC Earth",
    "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/BBC_Earth.svg/1280px-BBC_Earth.svg.png",
    "link": "https://csm-e-cetubilusordlive-85082641.csm.tubi.video/csm/live/749986858/3.m3u8;jsessionid=4BD2C6E130339B7A14DBCEEF292C175D.csm-e-cetubilusordlive-85082641.csm.tubi.video?playback_start_ts=1764507308&yo.ap=https://lna.tubi.video/prd-yospace/&yo.t.jt=1000&",
    "category": "international",
    "streamType": "hls",
    "createdAt": 1764507423184
  },
  {
    "id": "milqbqsrtsfeu2gey",
    "name": "Motorsport.Tv",
    "logo": "https://upload.wikimedia.org/wikipedia/commons/1/10/Motorsport.com_Logo.png",
    "link": "https://4d946db4.wurl.com/manifest/f36d25e7e52f1ba8d7e56eb859c636563214f541/VmlkYWEtZ2JfTW90b3JzcG9ydHR2X0hMUw/532fc089-ff4a-43d4-9a95-70eac0029a56/2.m3u8",
    "category": "sports",
    "streamType": "hls",
    "createdAt": 1764507699819
  },
  {
    "id": "milqdz0ea2r0h7kaj",
    "name": "FIFA+",
    "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/FIFA%2B_%282025%29.svg/2560px-FIFA%2B_%282025%29.svg.png",
    "link": "https://c822c659.wurl.com/manifest/f36d25e7e52f1ba8d7e56eb859c636563214f541/U2Ftc3VuZy1pbl9GSUZBUGx1c0VuZ2xpc2hfSExT/00070c81-18b3-492b-87f1-5c034e41aad6/0.m3u8",
    "category": "sports",
    "streamType": "hls",
    "createdAt": 1764507803774
  },
  {
    "id": "milqg0jx6iuemh8ni",
    "name": "Redbull Tv",
    "logo": "https://static.wikia.nocookie.net/logopedia/images/3/3c/Red_Bull_TV.svg/revision/latest?cb=20180423100712",
    "link": "https://rbmn-live.akamaized.net/hls/live/590964/BoRB-AT/master_1660.m3u8",
    "category": "sports",
    "streamType": "hls",
    "createdAt": 1764507899085
  },
  {
    "id": "milqip0yab4cawmds",
    "name": "Realmadrid Tv",
    "logo": "https://pbs.twimg.com/media/GyIXeuoWoAAUO30.jpg",
    "link": "https://b96bc664.wurl.com/manifest/f36d25e7e52f1ba8d7e56eb859c636563214f541/VENMVFZQbHVzLWNhX1JlYWxNYWRyaWRfSExT/413e650d-abd8-4117-996d-b7db94617b95/0.m3u8",
    "category": "sports",
    "streamType": "hls",
    "createdAt": 1764508024114
  },
  {
    "id": "milqlv81t6vp17ik8",
    "name": "DD Sports ",
    "logo": "https://static.wikia.nocookie.net/logopedia/images/4/48/DD_Sports.png/revision/latest?cb=20160805130643",
    "link": "https://d3qs3d2rkhfqrt.cloudfront.net/out/v1/b17adfe543354fdd8d189b110617cddd/index_3.m3u8",
    "category": "sports",
    "streamType": "hls",
    "createdAt": 1764508172113
  },
  {
    "id": "milqo2ctbjp5ekhsh",
    "name": "DD Tamil HD",
    "logo": "https://i.ytimg.com/vi/Oan9OD7ZpxU/sddefault.jpg",
    "link": "https://d2lk5u59tns74c.cloudfront.net/out/v1/abf46b14847e45499f4a47f3a9afe93d/index_3.m3u8",
    "category": "tamil",
    "streamType": "hls",
    "createdAt": 1764508274669
  },
  {
    "id": "milqrr4oivjkxhnrj",
    "name": "Sana Plus HD",
    "logo": "https://play-lh.googleusercontent.com/dlB8gw2yqzd8bcuvtgux5jJT-Ul26SjZio7Dsk_0qhR9ZzF3NxxbvZqjWF8kej_tUQ",
    "link": "https://galaxyott.live//hls/sanaplus.m3u8",
    "category": "tamil",
    "streamType": "hls",
    "createdAt": 1764508446744
  },
  {
    "id": "milqtny5ppjzsd4mt",
    "name": "Sai Tv Tamil",
    "logo": "https://m.media-amazon.com/images/I/81ObpGqpejL.png",
    "link": "https://account30.livebox.co.in/saitvhls/live.m3u8",
    "category": "devotional",
    "streamType": "hls",
    "createdAt": 1764508535933
  },
  {
    "id": "milqwn4hy8i0qf4nx",
    "name": "Max Music HD",
    "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTWBtIcpysn80fmsZ8Hm39jD5VOgNTUGdO6Kv_P5lV9G9A3QmFiFkKDUYXnztthPqUWtJU&usqp=CAU",
    "link": "https://live.maxtn.in/maxmusic/maxmusic/tracks-v1a1/mono.m3u8",
    "category": "music",
    "streamType": "hls",
    "createdAt": 1764508674833
  },
  {
    "id": "milr0eh9g6tj619v4",
    "name": "Raj Tv",
    "logo": "https://d330rbx7lebtkh.cloudfront.net/cholafiles/posters/MUUJy44KVO.jpeg",
    "link": "https://d3qs3d2rkhfqrt.cloudfront.net/out/v1/2839e3d1e0f84a2e821c1708d5fdfdf0/index_1.m3u8",
    "category": "tamil",
    "streamType": "hls",
    "createdAt": 1764508850253
  },
  {
    "id": "milr2hwijf35omyvq",
    "name": "Kalaignar Tv",
    "logo": "https://www.medianews4u.com/wp-content/uploads/2019/07/kalaignar.jpg",
    "link": "https://segment.yuppcdn.net/240122/kalaignartv/240122/kalaignartv_1800/chunks.m3u8",
    "category": "tamil",
    "streamType": "hls",
    "createdAt": 1764508948002
  },
  {
    "id": "milr4ta6x8aa27h6a",
    "name": "Sirippoli",
    "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQlXUODTpC3pfkDvt86dn2yiHdTzby3posNA&s",
    "link": "https://yuppmedtaorire.akamaized.net/v1/manifest/a0d007312bfd99c47f76b77ae26b1ccdaae76cb1/siripoli_nim_https/4b42179e-dec0-4013-aec0-fe3afdfdcbf9/0.m3u8",
    "category": "tamil",
    "streamType": "hls",
    "createdAt": 1764509056062
  },
  {
    "id": "milr9bml0edh38h1u",
    "name": "Vendhar Tv",
    "logo": "https://upload.wikimedia.org/wikipedia/en/0/0e/Logo_of_Vendhar_TV.jpg",
    "link": "https://cdn-3.pishow.tv/live/1271/1271_1.m3u8",
    "category": "tamil",
    "streamType": "hls",
    "createdAt": 1764509266461
  },
  {
    "id": "milrcnuceqqgp1d14",
    "name": "Makkal Tv",
    "logo": "https://jiotvimages.cdn.jio.com/dare_images/images/200/-/Makkal_TV.png",
    "link": "https://5k8q87azdy4v-hls-live.wmncdn.net/MAKKAL/271ddf829afeece44d8732757fba1a66.sdp/chunks.m3u8",
    "category": "tamil",
    "streamType": "hls",
    "createdAt": 1764509422260
  },
  {
    "id": "milrj1m4sxl28u6sr",
    "name": "Polimer Tv",
    "logo": "https://d229kpbsb5jevy.cloudfront.net/bott/content/channels/tvguide/1708093160719.png",
    "link": "https://cdn-2.pishow.tv/live/1241/1241_1.m3u8",
    "category": "tamil",
    "streamType": "hls",
    "createdAt": 1764509720044
  },
  {
    "id": "milt2alsln2n17y",
    "name": "MoviesFD",
    "logo": "https://movies-fd.sbs/wp-content/uploads/MoviesFD-Giffed-Logo.gif",
    "link": "https://movies-fd.sbs/latest/",
    "category": "movie",
    "streamType": "auto",
    "createdAt": 1764512297776
  },
  {
    "id": "milt4lkpuprltmy",
    "name": "Olamovies",
    "logo": "https://new4.olamovies.onl/wp-content/uploads/2024/04/logo@2x_transparent.png",
    "link": "https://new4.olamovies.onl/",
    "category": "movie",
    "streamType": "auto",
    "createdAt": 1764512405305
  },
  {
    "id": "milt67qyr5w00b8",
    "name": "YTS",
    "logo": "https://ytsrs.com/imgs/ytsrs-logo.svg",
    "link": "https://ytsrs.com/",
    "category": "movie",
    "streamType": "auto",
    "createdAt": 1764512480698
  },
  {
    "id": "milt8c3qhsnpqy7",
    "name": "Isaimini",
    "logo": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQBAMAAADt3eJSAAAAG1BMVEXMzMwAAAAiJikpLTAvNDg2O0BCSU9KUFddZGsIgmjaAAAAAXRSTlMAQObYZgAAADBJREFUeAFjQAaCAgxoQEkBhODA2ACK4MDFAYrgIDQAiuAgLQGK4KC8AIrgoKMBggBI1A1pwAF9ewAAAABJRU5ErkJggg==",
    "link": "https://xn--3-lve1d0cya6hb2e.com/",
    "category": "movie",
    "streamType": "auto",
    "createdAt": 1764512579654
  },
  {
    "id": "minc0upkxesc9o4",
    "name": "Gem Tv",
    "logo": "https://play-lh.googleusercontent.com/k5TcYle8d8oos-bzskFadGGyeQwjBD2kdDq-8ORnxlspwmnZBxISSVp55nCNQGiuYxM=w526-h296-rw",
    "link": "https://gemtv.circle7stream.com/gem/fcce47a8559e30755582c396ce7fce9e.sdp/playlist.m3u8",
    "category": "tamil",
    "streamType": "hls",
    "createdAt": 1764604609400
  },
  {
    "id": "minc5cs5x9ezcmp",
    "name": "CTN Tv",
    "logo": "https://play-lh.googleusercontent.com/RNJI7zZh3z3FU-KkGLsyJou7JVmXU7jh9LA8V1zYfMiHymnmgLTZrCnyB-NeSk_OrGQMCMG2-jmssbeovxt6RMg=w526-h296-rw",
    "link": "https://live.olidigital.in/ctnchannel/ctnchannel/tracks-v1a1/mono.m3u8",
    "category": "tamil-local-channel",
    "streamType": "hls",
    "createdAt": 1764604819445
  },
  {
    "id": "mincao446vmqmr0",
    "name": "Kovai Tv",
    "logo": "https://yt3.googleusercontent.com/ytc/AIdro_mFFFS7q9vrDaF7fZb5VyzWiigCCe980oyqJVC6uYeV3_Y=s160-c-k-c0x00ffffff-no-rj",
    "link": "https://account31.livebox.co.in/Kovaitvhls/live.m3u8",
    "category": "tamil-local-channel",
    "streamType": "hls",
    "createdAt": 1764605067412
  },
  {
    "id": "mincdvmcb0dtpx3",
    "name": "Vedha Tv",
    "logo": "https://oxolive.com/wp-content/uploads/2025/10/ChatGPT-Image-Oct-3-2025-09_45_32-PM-1.png",
    "link": "https://skystream.in/live/vedha6528/index.m3u8",
    "category": "tamil-local-channel",
    "streamType": "hls",
    "createdAt": 1764605217108
  },
  {
    "id": "mincgmlfdk2v9i5",
    "name": "Udhayam Tv",
    "logo": "https://play-lh.googleusercontent.com/RxHuH9lLS2V6QmxUdnZ0oTahq9myUQHn7nNSVwExxQLKadT5QMRPRiIFl3H-nmiylmmY",
    "link": "https://ipcloud.live/udhayamtv/live/tracks-v1a1/mono.m3u8",
    "category": "tamil-local-channel",
    "streamType": "hls",
    "createdAt": 1764605345379
  },
  {
    "id": "mincivrx1suj0mm",
    "name": "Shalini Tv",
    "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTFFMBuoSYZTog3_2Yj5EDXiHG6FCD7LTBccQ&s",
    "link": "https://ipcloud.live/shalinitv/shalinitv/tracks-v1a1/mono.m3u8",
    "category": "tamil-local-channel",
    "streamType": "hls",
    "createdAt": 1764605450589
  },
  {
    "id": "mincmwjmlg25byn",
    "name": "Motorvision Tv",
    "logo": "https://pbs.twimg.com/profile_images/1364953286168698886/ZtoiZzW5_400x400.jpg",
    "link": "https://mvg-mv-xumo.otteravision.com/mvg/mv/mv.m3u8",
    "category": "sports",
    "streamType": "hls",
    "createdAt": 1764605638210
  },
  {
    "id": "minctm57vp4033n",
    "name": "Always Funny ",
    "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQWXVe7ylJnE7NC9lcaiNQgjoXg8Bo3HSrT0A&s",
    "link": "https://livetv-fa.tubi.video/afv/playlist_1024x576.m3u8",
    "category": "international",
    "streamType": "hls",
    "createdAt": 1764605951323
  },
  {
    "id": "minczk7vgdt7cr5",
    "name": "Camp Spoopy",
    "logo": "https://img2.static-ottera.com/prod/tg/linear_channel/logo/960x540/camp-spoopy-2021_1920-x-1080_option-5.jpg",
    "link": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=269",
    "category": "kids",
    "streamType": "hls",
    "createdAt": 1764606228763
  },
  {
    "id": "mind1rv69gzgzuf",
    "name": "Disney Channel",
    "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6c/2014_Disney_Channel_logo.svg/2560px-2014_Disney_Channel_logo.svg.png",
    "link": "https://fl31.moveonjoy.com/DISNEY/tracks-v1a1/mono.ts.m3u8",
    "category": "kids",
    "streamType": "hls",
    "createdAt": 1764606331986
  },
  {
    "id": "mind48pgvy3payh",
    "name": "Kidsflix",
    "logo": "https://play-lh.googleusercontent.com/cPTAAvCeTEG6nu_ofBT-9xP1qfk6gU7AxM_z4Cwv_-zFQOLAND7ja6z1KnuMkWb3J-k=w600-h300-pc0xffffff-pd",
    "link": "https://stream-us-east-1.getpublica.com/playlist.m3u8?network_id=50",
    "category": "kids",
    "streamType": "hls",
    "createdAt": 1764606447124
  },
  {
    "id": "mind6iwhu101tm3",
    "name": "Nicktoons",
    "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Nicktoons_Logo_2023.svg/1200px-Nicktoons_Logo_2023.svg.png",
    "link": "https://fl1.moveonjoy.com/NICKTOONS/tracks-v1a1/mono.m3u8",
    "category": "kids",
    "streamType": "hls",
    "createdAt": 1764606553649
  },
  {
    "id": "miookgomlw6hx1d",
    "name": "Tamil Tv HD",
    "logo": "https://vipotv.com/wp-content/uploads/2021/11/tamil-tv-live-vipotv-india.png",
    "link": "https://ktismaservers.in:3220/hybrid/play.m3u8",
    "backupLink": "",
    "category": "tamil",
    "streamType": "hls",
    "createdAt": 1764686145910
  },
  {
    "id": "miooqmtu53givt3",
    "name": "RT Tv",
    "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a0/Russia-today-logo.svg/1200px-Russia-today-logo.svg.png",
    "link": "https://rt-glb.rttv.com/live/rtnews/playlist.m3u8",
    "backupLink": "https://rt-glb.rttv.com/live/rtnews/playlist_2500Kb.m3u8",
    "category": "international",
    "streamType": "hls",
    "createdAt": 1764686433810
  },
  {
    "id": "miovmoontv",
    "name": "Moon Tv",
    "logo": "https://static.wikia.nocookie.net/logopedia/images/1/1d/Moon_TV.jpg/revision/latest?cb=20191225181654",
    "link": "https://yuppftalive.akamaized.net/080823/moontv/playlist.m3u8?hdnts=st=1764750605~exp=1764754205~acl=!*/080823/moontv/*!yuppTVCom_5_24049354_c24505a291c14922_US_65.181.111.29~data=yuppTVCom_5_24049354_c24505a291c14922_US_65.181.111.29~hmac=26bfec235ef0c66c2c75e45f35dcc6626211282465eadf357474a3d226fea8e9&ads.app_bundle=&ads.app_store_url=&ads.content_livestream=1&ads.language=TAM&ads.content_genre=ENT&ads.channel=6418&ads.channel_name=MoonTV&ads.network_name=yupptv&ads.user=0",
    "category": "tamil",
    "streamType": "hls",
    "createdAt": 1764750605000
  },
  {
    "id": "news18_tn_hd_custom_add",
    "name": "NEWS 18 Tamil Nadu HD",
    "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSuY4bwiyxhFXko1SPxhIkV142RLPyBplR_0A&s",
    "link": "https://nw18live.cdn.jio.com/bpk-tv/News18_Tamil_Nadu_NW18_MOB/output01/News18_Tamil_Nadu_NW18_MOB-audio_98835_eng=98800-video=3724000.m3u8",
    "category": "news",
    "streamType": "hls",
    "createdAt": 1764841000000
  },
  {
    "id": "zee_news_tamil_hd_custom_add",
    "name": "Zee News TamilHD",
    "logo": "https://images.seeklogo.com/logo-png/62/1/zee-tamil-news-logo-png_seeklogo-629912.png",
    "link": "https://dpkvdnzbeen1l.cloudfront.net/index_4.m3u8",
    "category": "news",
    "streamType": "hls",
    "createdAt": 1764841500000
  },
  {
    "id": "france24_news_custom_add",
    "name": "France24",
    "logo": "https://yt3.googleusercontent.com/ytc/AIdro_n_QTJ5-GLGnftQFkb7Kp36W2eBH3H-7ZqTQxzFkkqGrIE=s900-c-k-c0x00ffffff-no-rj",
    "link": "https://a-cdn.klowdtv.com/live2/france24_720p/chunks.m3u8",
    "category": "news",
    "streamType": "hls",
    "createdAt": 1764842000000
  },
  {
    "id": "vaanavil_tv_custom_add",
    "name": "Vaanavil Tv",
    "logo": "https://static.wikia.nocookie.net/logopedia/images/2/26/Vaanavil.jpeg/revision/latest?cb=20191226090031",
    "link": "https://6n3yope4d9ok-hls-live.5centscdn.com/vaanavil/TV.stream/chunks.m3u8",
    "category": "tamil",
    "streamType": "hls",
    "createdAt": 1764843000000
  },
  {
    "id": "jcv_tv_custom_add",
    "name": "JCV",
    "logo": "https://www.tamiltvchannels.com/img/tamil%20local/JCV%20TV.gif",
    "link": "https://play.applelive.in/jcvtv/jcvtv.m3u8",
    "category": "tamil-local-channel",
    "streamType": "hls",
    "createdAt": 1764844000000
  },
  {
    "id": "mallar_tv_custom_add",
    "name": "Mallar Tv",
    "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRCv0mIyxDd7mhce6jT4NdekCPdId9wdGiadw&s",
    "link": "https://sscloud7.com/live/malartv/index.m3u8",
    "category": "tamil-local-channel",
    "streamType": "hls",
    "createdAt": 1764845000000
  },
  {
    "id": "jc_tv_custom_add",
    "name": "JC Tv",
    "logo": "https://play-lh.googleusercontent.com/-Hmivn2TxPJogGdfNtHWrLyRGOzMINQM57LzGYz262ML2-hMoeXv-noFvRPtCZXdv9gi",
    "link": "https://play.applelive.in/jctv/jctv.m3u8",
    "category": "tamil-local-channel",
    "streamType": "hls",
    "createdAt": 1764845100000
  },
  {
    "id": "selfie_tv_custom_add",
    "name": "Selfie Tv",
    "logo": "https://www.tamiltvchannels.com/img/tamil%20local/selfie%20tv.png",
    "link": "https://play.applelive.in/selfeetv/selfeetv.m3u8",
    "category": "tamil-local-channel",
    "streamType": "hls",
    "createdAt": 1764845200000
  },
  {
    "id": "v_tv_custom_add",
    "name": "V Tv",
    "logo": "https://www.tamiltvchannels.com/img/tamil%20local/V%20TV.gif",
    "link": "https://play.applelive.in/vtv/vtv.m3u8",
    "category": "tamil-local-channel",
    "streamType": "hls",
    "createdAt": 1764846000000
  },
  {
    "id": "jcv_musix_tv_custom_add",
    "name": "JCV Musix Tv",
    "logo": "https://www.tamiltvchannels.com/img/tamil%20local/jcv%20musix.gif",
    "link": "https://play.applelive.in/jcvtv/jcvmusix.m3u8",
    "category": "tamil-local-channel",
    "streamType": "hls",
    "createdAt": 1764846100000
  },
  {
    "id": "digital_tv_custom_add",
    "name": "Digital Tv",
    "logo": "https://www.tamiltvchannels.com/img/tamil%20local/digital%20tv.png",
    "link": "https://play.applelive.in/digitaltv/digitaltv.m3u8",
    "category": "tamil-local-channel",
    "streamType": "hls",
    "createdAt": 1764846200000
  },
  {
    "id": "garudan_tv_custom_add",
    "name": "Garudan Tv",
    "logo": "https://www.tamiltvchannels.com/img/Devotional%20H/Garudan.png",
    "link": "https://play.applelive.in/hls/garudantv.m3u8",
    "category": "devotional",
    "streamType": "hls",
    "createdAt": 1764847000000
  },
  {
    "id": "tamilan_tv_custom_add",
    "name": "Tamilan Tv",
    "logo": "https://content.jdmagicbox.com/v2/comp/chennai/47/044p7017447/catalogue/tamilan-tv-virugambakkam-chennai-satellite-channels-1g9oe1atpx.jpg",
    "link": "https://cdn.zionmediait.com/zionmediaitserver2024/97484f5ce6da96e496a9b87c439835d0.sdp/chunks.m3u8",
    "category": "tamil",
    "streamType": "hls",
    "createdAt": 1764848000000
  },
  {
    "id": "fancode_sports_custom_add",
    "name": "Fancode",
    "logo": "https://upload.wikimedia.org/wikipedia/en/thumb/6/6c/FanCode_logo.svg/1200px-FanCode_logo.svg.png",
    "link": "https://in-mc-fdlive.fancode.com/mumbai/138624_english_hls_c25647f7a045413_1ta-di_h264/index.m3u8",
    "category": "sports",
    "streamType": "hls",
    "createdAt": 1764849000000
  }
];