
import React, { useState, useEffect } from 'react';
import { Channel, CategoryItem, Notification, AppSettings, PromoItem } from '../types';
import { ADMIN_PASSWORD } from '../constants';
import { loadNotifications, saveNotifications } from '../services/storageService';
import { 
  Lock, LogIn, Plus, Trash2, Edit2, Save, LogOut, 
  LayoutGrid, Tv, Bell, Send, Settings as SettingsIcon, CheckCircle,
  Eye, EyeOff, Megaphone, Link as LinkIcon, Image as ImageIcon,
  PlayCircle, Code, Copy, Upload, Play, Square, AlertCircle
} from 'lucide-react';
import VideoPlayer from './VideoPlayer';

interface AdminPanelProps {
  channels: Channel[];
  categories: CategoryItem[];
  promos: PromoItem[];
  settings: AppSettings;
  onUpdateChannels: (channels: Channel[]) => void;
  onUpdateCategories: (categories: CategoryItem[]) => void;
  onUpdatePromos: (promos: PromoItem[]) => void;
  onUpdateSettings: (settings: AppSettings) => void;
  onClose: () => void;
}

type Tab = 'channels' | 'categories' | 'promos' | 'notifications' | 'settings';

// Simple ID generator to avoid external dependency issues
const generateId = () => Date.now().toString(36) + Math.random().toString(36).substring(2, 9);

const AdminPanel: React.FC<AdminPanelProps> = ({ 
  channels, 
  categories, 
  promos,
  settings,
  onUpdateChannels, 
  onUpdateCategories, 
  onUpdatePromos,
  onUpdateSettings,
  onClose 
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState<Tab>('channels');

  // --- Channel Form State ---
  const [editId, setEditId] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [logo, setLogo] = useState('');
  const [link, setLink] = useState('');
  const [backupLink, setBackupLink] = useState(''); // New State
  const [category, setCategory] = useState<string>('tamil');
  const [streamType, setStreamType] = useState<'auto' | 'hls' | 'youtube' | 'mp4' | 'iframe'>('auto');
  const [channelSuccess, setChannelSuccess] = useState('');

  // --- Category Form State ---
  const [catName, setCatName] = useState('');

  // --- Promo Form State ---
  const [promoTitle, setPromoTitle] = useState('');
  const [promoImg, setPromoImg] = useState('');
  const [promoLink, setPromoLink] = useState('');
  // Replaced simple boolean with badge state
  const [promoBadge, setPromoBadge] = useState<'none' | 'live' | 'coming_soon' | 'streaming'>('none');
  const [promoChannelId, setPromoChannelId] = useState('');
  const [previewPromoId, setPreviewPromoId] = useState<string | null>(null);

  // --- Notification Form State ---
  const [notifTitle, setNotifTitle] = useState('');
  const [notifMsg, setNotifMsg] = useState('');
  const [notifSuccess, setNotifSuccess] = useState('');

  // --- Settings Form State ---
  const [aboutContent, setAboutContent] = useState(settings.aboutContent);
  const [shareTitle, setShareTitle] = useState(settings.shareTitle);
  const [shareText, setShareText] = useState(settings.shareText);
  const [shareUrl, setShareUrl] = useState(settings.shareUrl);
  const [enableAds, setEnableAds] = useState(settings.enableAds !== undefined ? settings.enableAds : true);
  const [settingsSuccess, setSettingsSuccess] = useState('');

  // --- Export State ---
  const [generatedCode, setGeneratedCode] = useState('');

  // Update form state if props change (e.g. initial load)
  useEffect(() => {
    setAboutContent(settings.aboutContent);
    setShareTitle(settings.shareTitle);
    setShareText(settings.shareText);
    setShareUrl(settings.shareUrl);
    setEnableAds(settings.enableAds !== undefined ? settings.enableAds : true);
  }, [settings]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      setIsAuthenticated(true);
      setError('');
    } else {
      setError('Incorrect password');
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, setter: (val: string) => void) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setter(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // --- Channel Logic ---
  const handleLinkChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setLink(val);
    
    // Auto-detect stream type
    if (val.includes('.m3u8')) setStreamType('hls');
    else if (val.includes('youtube.com') || val.includes('youtu.be')) setStreamType('youtube');
    else if (val.endsWith('.mp4')) setStreamType('mp4');
    else setStreamType('auto');
  };

  const handleSaveChannel = () => {
    if (!name.trim() || !link.trim()) {
      alert('Name and Link are required');
      return;
    }

    let updatedChannels = [...channels];
    let successMsg = '';

    if (editId) {
      updatedChannels = updatedChannels.map(c => 
        c.id === editId ? { ...c, name, logo, link, backupLink, category, streamType } : c
      );
      successMsg = 'Channel updated successfully!';
    } else {
      const newChannel: Channel = {
        id: generateId(),
        name,
        logo: logo || `https://via.placeholder.com/320x180?text=${encodeURIComponent(name)}`,
        link,
        backupLink,
        category,
        streamType,
        createdAt: Date.now()
      };
      updatedChannels.push(newChannel);
      successMsg = 'Channel added successfully!';
    }

    onUpdateChannels(updatedChannels);
    setChannelSuccess(successMsg);
    setTimeout(() => setChannelSuccess(''), 3000);
    resetChannelForm();
  };

  const handleEditChannelStart = (c: Channel) => {
    setEditId(c.id);
    setName(c.name);
    setLogo(c.logo);
    setLink(c.link);
    setBackupLink(c.backupLink || '');
    setCategory(c.category);
    setStreamType(c.streamType || 'auto');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDeleteChannel = (id: string) => {
    if (confirm('Are you sure you want to delete this channel?')) {
      onUpdateChannels(channels.filter(c => c.id !== id));
    }
  };

  const resetChannelForm = () => {
    setEditId(null);
    setName('');
    setLogo('');
    setLink('');
    setBackupLink('');
    setCategory('tamil');
    setStreamType('auto');
  };

  // --- Category Logic ---
  const handleAddCategory = () => {
    if (!catName.trim()) return;
    const id = catName.toLowerCase().replace(/[^a-z0-9]/g, '-');
    
    if (categories.some(c => c.id === id)) {
      alert('Category already exists!');
      return;
    }

    const newCat: CategoryItem = { id, label: catName };
    onUpdateCategories([...categories, newCat]);
    setCatName('');
  };

  const handleDeleteCategory = (id: string) => {
    if (id === 'all') return;
    if (confirm(`Delete category '${id}'? Channels in this category might get hidden.`)) {
      onUpdateCategories(categories.filter(c => c.id !== id));
    }
  };

  // --- Promo Logic ---
  const handlePromoChannelSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const chId = e.target.value;
    setPromoChannelId(chId);
    if (chId) {
      const channel = channels.find(c => c.id === chId);
      if (channel) {
         setPromoTitle(channel.name);
         setPromoImg(channel.logo);
         setPromoLink(''); 
         setPromoBadge('live'); // Default to Live if selecting a channel
      }
    }
  };

  const handleAddPromo = () => {
    if (!promoImg.trim()) {
      alert("Image URL is required");
      return;
    }

    const newPromo: PromoItem = {
      id: generateId(),
      title: promoTitle || 'Untitled Promo',
      imageUrl: promoImg,
      link: promoLink,
      isActive: true,
      isLive: promoBadge === 'live', // Legacy support
      badge: promoBadge,
      channelId: promoChannelId || undefined
    };

    onUpdatePromos([...promos, newPromo]);
    setPromoTitle('');
    setPromoImg('');
    setPromoLink('');
    setPromoBadge('none');
    setPromoChannelId('');
  };

  const handleDeletePromo = (e: React.MouseEvent, id: string, index: number) => {
    e.preventDefault();
    e.stopPropagation();
    
    // Always confirm
    if (window.confirm("Are you sure you want to permanently delete this banner?")) {
      let updatedPromos;
      // If ID exists, filter by ID (standard)
      if (id) {
          updatedPromos = promos.filter(p => p.id !== id);
      } else {
          // Fallback: Delete by index if ID is missing (fixes "undeletable" banners)
          updatedPromos = promos.filter((_, i) => i !== index);
      }
      onUpdatePromos(updatedPromos);
    }
  };

  // --- Notification Logic ---
  const handleSendNotification = () => {
    if (!notifTitle.trim() || !notifMsg.trim()) {
      alert("Title and message required");
      return;
    }

    const newNotif: Notification = {
      id: generateId(),
      title: notifTitle,
      message: notifMsg,
      timestamp: Date.now()
    };

    const current = loadNotifications();
    saveNotifications([...current, newNotif]);
    
    setNotifTitle('');
    setNotifMsg('');
    setNotifSuccess('Notification sent successfully! Users will see it on next refresh.');
    setTimeout(() => setNotifSuccess(''), 3000);
  };

  // --- Settings Logic ---
  const handleSaveSettings = () => {
    onUpdateSettings({
      aboutContent,
      shareTitle,
      shareText,
      shareUrl,
      enableAds
    });
    setSettingsSuccess('Settings updated successfully!');
    setTimeout(() => setSettingsSuccess(''), 3000);
  };

  const generateSourceCode = () => {
    const code = `
// --- COPY THIS INTO constants.ts ---

import { Channel, CategoryItem, AppSettings, PromoItem } from './types';

export const STORAGE_KEY = 'live_tv_channels_v5';
export const CATEGORIES_KEY = 'live_tv_categories_v1';
export const NOTIFICATIONS_KEY = 'live_tv_notifications_v1';
export const PROMOS_KEY = 'live_tv_promos_v1';
export const SETTINGS_KEY = 'live_tv_settings_v1';
export const FAVORITES_KEY = 'live_tv_favorites_v1';

export const DATA_VERSION = ${Date.now()}; // Auto-generated timestamp

export const ADMIN_PASSWORD = '${ADMIN_PASSWORD}'; 
export const ADSENSE_CLIENT_ID = 'ca-pub-0000000000000000'; // Replace with ID

export const DEFAULT_SETTINGS: AppSettings = ${JSON.stringify({
  aboutContent,
  shareTitle,
  shareText,
  shareUrl,
  enableAds
}, null, 2)};

export const DEFAULT_CATEGORIES: CategoryItem[] = ${JSON.stringify(categories, null, 2)};

export const DEFAULT_PROMOS: PromoItem[] = ${JSON.stringify(promos, null, 2)};

export const DEFAULT_CHANNELS: Channel[] = ${JSON.stringify(channels, null, 2)};
`;
    setGeneratedCode(code);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedCode);
    alert("Code copied! Paste this into constants.ts");
  };

  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto mt-10 p-8 bg-[#15181a] rounded-xl shadow-lg border border-gray-800">
        <div className="flex flex-col items-center mb-6">
          <div className="w-12 h-12 bg-gray-800 rounded-full flex items-center justify-center mb-4">
            <Lock className="w-6 h-6 text-[#00d1ff]" />
          </div>
          <h2 className="text-xl font-bold text-white">Admin Access</h2>
          <p className="text-gray-400 text-sm mt-1">Enter password to manage channels</p>
        </div>
        
        <form onSubmit={handleLogin} className="space-y-4">
          <div className="relative">
            <input
              type={showPassword ? "text" : "password"}
              placeholder="Password"
              className="w-full bg-[#0f1113] border border-gray-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#00d1ff] transition-colors pr-12"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white focus:outline-none"
            >
              {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
            </button>
            {error && <p className="text-red-500 text-xs mt-2 absolute -bottom-5 left-0">{error}</p>}
          </div>
          <div className="flex gap-3 pt-2">
            <button
              type="submit"
              className="flex-1 bg-[#00d1ff] hover:bg-[#00b8e6] text-[#0f1113] font-bold py-3 rounded-lg flex items-center justify-center gap-2 transition-colors"
            >
              <LogIn size={18} /> Login
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-3 rounded-lg bg-gray-700 hover:bg-gray-600 text-white transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto pb-20 animate-fade-in">
      <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
        <h2 className="text-2xl font-bold text-white">Admin Dashboard</h2>
        <button
          onClick={onClose}
          className="bg-red-500/10 hover:bg-red-500/20 text-red-500 px-4 py-2 rounded-lg flex items-center gap-2 transition-colors text-sm"
        >
          <LogOut size={16} /> Exit
        </button>
      </div>

      {/* Navigation Tabs */}
      <div className="flex space-x-2 mb-6 border-b border-gray-800 pb-1 overflow-x-auto custom-scrollbar">
        <button 
          onClick={() => setActiveTab('channels')}
          className={`flex items-center gap-2 px-6 py-3 rounded-t-lg font-medium transition-colors border-b-2 whitespace-nowrap ${activeTab === 'channels' ? 'bg-[#15181a] border-[#00d1ff] text-[#00d1ff]' : 'border-transparent text-gray-400 hover:text-white'}`}
        >
          <Tv size={18} /> Manage Channels
        </button>
        <button 
          onClick={() => setActiveTab('categories')}
          className={`flex items-center gap-2 px-6 py-3 rounded-t-lg font-medium transition-colors border-b-2 whitespace-nowrap ${activeTab === 'categories' ? 'bg-[#15181a] border-[#00d1ff] text-[#00d1ff]' : 'border-transparent text-gray-400 hover:text-white'}`}
        >
          <LayoutGrid size={18} /> Categories
        </button>
        <button 
          onClick={() => setActiveTab('promos')}
          className={`flex items-center gap-2 px-6 py-3 rounded-t-lg font-medium transition-colors border-b-2 whitespace-nowrap ${activeTab === 'promos' ? 'bg-[#15181a] border-[#00d1ff] text-[#00d1ff]' : 'border-transparent text-gray-400 hover:text-white'}`}
        >
          <Megaphone size={18} /> Promotions
        </button>
        <button 
          onClick={() => setActiveTab('notifications')}
          className={`flex items-center gap-2 px-6 py-3 rounded-t-lg font-medium transition-colors border-b-2 whitespace-nowrap ${activeTab === 'notifications' ? 'bg-[#15181a] border-[#00d1ff] text-[#00d1ff]' : 'border-transparent text-gray-400 hover:text-white'}`}
        >
          <Bell size={18} /> Notifications
        </button>
        <button 
          onClick={() => setActiveTab('settings')}
          className={`flex items-center gap-2 px-6 py-3 rounded-t-lg font-medium transition-colors border-b-2 whitespace-nowrap ${activeTab === 'settings' ? 'bg-[#15181a] border-[#00d1ff] text-[#00d1ff]' : 'border-transparent text-gray-400 hover:text-white'}`}
        >
          <SettingsIcon size={18} /> App Settings
        </button>
      </div>

      {/* === CHANNELS TAB === */}
      {activeTab === 'channels' && (
        <>
          {/* Editor Form */}
          <div className="bg-[#15181a] p-6 rounded-xl border border-gray-800 mb-8 shadow-lg">
            <h3 className="text-lg font-semibold text-[#00d1ff] mb-4 flex items-center gap-2">
              {editId ? <Edit2 size={18} /> : <Plus size={18} />}
              {editId ? 'Edit Channel' : 'Add New Channel'}
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="space-y-1">
                <label className="text-xs text-gray-400 uppercase font-semibold">Channel Name</label>
                <input
                  className="w-full bg-[#0f1113] border border-gray-700 rounded-lg px-3 py-2 text-white focus:border-[#00d1ff] focus:outline-none"
                  placeholder="e.g. Sun TV"
                  value={name}
                  onChange={e => setName(e.target.value)}
                />
              </div>
              <div className="space-y-1">
                 <label className="text-xs text-gray-400 uppercase font-semibold">Category</label>
                 <select
                  className="w-full bg-[#0f1113] border border-gray-700 rounded-lg px-3 py-2 text-white focus:border-[#00d1ff] focus:outline-none"
                  value={category}
                  onChange={e => setCategory(e.target.value)}
                >
                  {categories.filter(c => c.id !== 'all').map(cat => (
                    <option key={cat.id} value={cat.id}>{cat.label}</option>
                  ))}
                </select>
              </div>
              
              <div className="space-y-1 md:col-span-2">
                <label className="text-xs text-gray-400 uppercase font-semibold">Stream URL (Primary)</label>
                <div className="relative">
                  <PlayCircle className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 w-4 h-4" />
                  <input
                    className="w-full bg-[#0f1113] border border-gray-700 rounded-lg py-2 pl-9 pr-3 text-white focus:border-[#00d1ff] focus:outline-none font-mono text-sm"
                    placeholder="https://example.com/stream.m3u8"
                    value={link}
                    onChange={handleLinkChange}
                  />
                </div>
              </div>

              <div className="space-y-1 md:col-span-2">
                <label className="text-xs text-gray-400 uppercase font-semibold text-yellow-500">Backup Stream URL (Optional)</label>
                <div className="relative">
                  <PlayCircle className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 w-4 h-4" />
                  <input
                    className="w-full bg-[#0f1113] border border-gray-700 rounded-lg py-2 pl-9 pr-3 text-white focus:border-[#00d1ff] focus:outline-none font-mono text-sm"
                    placeholder="https://youtube.com/..."
                    value={backupLink}
                    onChange={(e) => setBackupLink(e.target.value)}
                  />
                </div>
                <p className="text-[10px] text-gray-500">Auto-switches to this link if the primary stream fails.</p>
              </div>

              <div className="space-y-1 md:col-span-2">
                 <label className="text-xs text-gray-400 uppercase font-semibold flex justify-between">
                    <span>Stream Type (Saved to DB)</span>
                    <span className="text-[#00d1ff] font-normal lowercase">{streamType}</span>
                 </label>
                 <select
                  className="w-full bg-[#0f1113] border border-gray-700 rounded-lg px-3 py-2 text-white focus:border-[#00d1ff] focus:outline-none"
                  value={streamType}
                  onChange={(e) => setStreamType(e.target.value as any)}
                >
                  <option value="auto">Auto Detect (Default)</option>
                  <option value="hls">HLS / M3U8 Stream</option>
                  <option value="youtube">YouTube</option>
                  <option value="mp4">MP4 Video</option>
                  <option value="iframe">Generic Iframe</option>
                </select>
                <p className="text-[10px] text-gray-500">
                   Force 'HLS' for m3u8 links that don't end in .m3u8 (e.g. tokenized urls).
                </p>
              </div>

              <div className="space-y-1 md:col-span-2">
                <label className="text-xs text-gray-400 uppercase font-semibold">Logo URL or Upload Image</label>
                <div className="flex gap-2">
                   <div className="relative flex-1">
                     <ImageIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 w-4 h-4" />
                     <input
                       className="w-full bg-[#0f1113] border border-gray-700 rounded-lg py-2 pl-9 pr-3 text-white focus:border-[#00d1ff] focus:outline-none font-mono text-sm"
                       placeholder="https://..."
                       value={logo}
                       onChange={e => setLogo(e.target.value)}
                     />
                   </div>
                   <label className="bg-gray-700 hover:bg-gray-600 text-white rounded-lg px-3 py-2 cursor-pointer transition-colors flex items-center justify-center">
                      <Upload size={18} />
                      <input type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, setLogo)} />
                   </label>
                </div>
                {logo && (
                  <div className="mt-2 h-16 w-full flex items-center gap-4 bg-[#0a0c0e] p-2 rounded border border-gray-800">
                    <img src={logo} alt="Preview" className="h-full object-contain max-w-[100px]" />
                    <span className="text-xs text-gray-500 truncate">{logo.length > 50 ? logo.substring(0,50) + '...' : logo}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="flex flex-col gap-3">
              <div className="flex gap-3">
                <button
                  onClick={handleSaveChannel}
                  className="flex-1 bg-[#00d1ff] hover:bg-[#00b8e6] text-[#0f1113] font-bold py-2.5 rounded-lg flex items-center justify-center gap-2 transition-all shadow-[0_0_15px_rgba(0,209,255,0.3)]"
                >
                  <Save size={18} /> {editId ? 'Save Changes' : 'Add Channel'}
                </button>
                {editId && (
                  <button
                    onClick={resetChannelForm}
                    className="px-6 py-2.5 bg-gray-700 hover:bg-gray-600 rounded-lg text-white font-medium transition-colors"
                  >
                    Cancel Edit
                  </button>
                )}
              </div>
              
              {channelSuccess && (
                <div className="bg-green-500/10 border border-green-500/50 text-green-500 px-4 py-2 rounded text-center text-sm flex items-center justify-center gap-2 animate-fade-in">
                    <CheckCircle size={16} /> {channelSuccess}
                </div>
              )}
            </div>
          </div>

          {/* List */}
          <div className="bg-[#15181a] rounded-xl border border-gray-800 overflow-hidden">
            <div className="p-4 border-b border-gray-800 bg-[#1a1d21]">
              <h3 className="font-semibold text-gray-300">Channel List ({channels.length})</h3>
            </div>
            <div className="divide-y divide-gray-800">
              {channels.map(channel => (
                <div key={channel.id} className="p-4 flex flex-col sm:flex-row sm:items-center gap-4 hover:bg-[#1a1d21] transition-colors">
                  <div className="w-24 h-14 bg-gray-900 rounded-md overflow-hidden flex-shrink-0 border border-gray-800">
                    <img src={channel.logo} alt={channel.name} className="w-full h-full object-contain" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-white truncate">{channel.name}</h4>
                    <div className="flex items-center gap-2 text-xs text-gray-400 mt-1">
                      <span className="bg-gray-800 px-2 py-0.5 rounded text-[#00d1ff] border border-gray-700">
                        {categories.find(c => c.id === channel.category)?.label || channel.category}
                      </span>
                      <span className="bg-gray-800 px-2 py-0.5 rounded text-gray-300 border border-gray-700 uppercase">
                        {channel.streamType || 'auto'}
                      </span>
                      {channel.backupLink && (
                         <span className="bg-yellow-500/20 px-2 py-0.5 rounded text-yellow-500 border border-yellow-500/30 text-[10px] font-bold">
                            HAS BACKUP
                         </span>
                      )}
                    </div>
                    <div className="text-xs text-gray-600 truncate mt-1 font-mono opacity-60">
                        {channel.link}
                    </div>
                  </div>
                  <div className="flex gap-2 mt-2 sm:mt-0">
                    <button
                      onClick={() => handleEditChannelStart(channel)}
                      className="p-2 bg-yellow-500/10 text-yellow-500 hover:bg-yellow-500 hover:text-black rounded-lg transition-colors"
                      title="Edit"
                    >
                      <Edit2 size={16} />
                    </button>
                    <button
                      onClick={() => handleDeleteChannel(channel.id)}
                      className="p-2 bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white rounded-lg transition-colors"
                      title="Delete"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {/* === CATEGORIES TAB === */}
      {activeTab === 'categories' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
           {/* Add Category */}
           <div className="md:col-span-1 bg-[#15181a] p-6 rounded-xl border border-gray-800 h-fit">
              <h3 className="text-lg font-semibold text-[#00d1ff] mb-4">Add Category</h3>
              <div className="space-y-4">
                 <input 
                    placeholder="Category Name (e.g. Comedy)"
                    className="w-full bg-[#0f1113] border border-gray-700 rounded-lg px-3 py-3 text-white focus:border-[#00d1ff] focus:outline-none"
                    value={catName}
                    onChange={(e) => setCatName(e.target.value)}
                 />
                 <button 
                   onClick={handleAddCategory}
                   className="w-full bg-[#00d1ff] hover:bg-[#00b8e6] text-[#0f1113] font-bold py-3 rounded-lg flex items-center justify-center gap-2"
                 >
                   <Plus size={18} /> Add Category
                 </button>
              </div>
           </div>

           {/* List Categories */}
           <div className="md:col-span-2 bg-[#15181a] rounded-xl border border-gray-800 overflow-hidden">
             <div className="p-4 border-b border-gray-800 bg-[#1a1d21]">
               <h3 className="font-semibold text-gray-300">Existing Categories</h3>
             </div>
             <div className="divide-y divide-gray-800 max-h-[500px] overflow-y-auto custom-scrollbar">
                {categories.map((cat) => (
                   <div key={cat.id} className="p-4 flex items-center justify-between hover:bg-[#1a1d21]">
                      <div>
                         <div className="font-medium text-white">{cat.label}</div>
                         <div className="text-xs text-gray-500 font-mono">ID: {cat.id}</div>
                      </div>
                      {!cat.isSystem ? (
                        <button 
                           onClick={() => handleDeleteCategory(cat.id)}
                           className="text-red-500 hover:bg-red-500/10 p-2 rounded transition-colors"
                           title="Delete Category"
                        >
                           <Trash2 size={18} />
                        </button>
                      ) : (
                         <span className="text-xs text-gray-600 bg-gray-800 px-2 py-1 rounded">System</span>
                      )}
                   </div>
                ))}
             </div>
           </div>
        </div>
      )}

      {/* === PROMOS TAB === */}
      {activeTab === 'promos' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
           {/* Add Promo */}
           <div className="bg-[#15181a] p-6 rounded-xl border border-gray-800 h-fit">
              <h3 className="text-lg font-semibold text-[#00d1ff] mb-4 flex items-center gap-2">
                 <Plus size={18} /> Add Banner
              </h3>
              <div className="space-y-4">
                 
                 {/* Channel Selector */}
                 <div>
                    <label className="text-xs text-gray-400 uppercase font-semibold block mb-1">Promote Specific Channel (Optional)</label>
                    <select 
                       className="w-full bg-[#0f1113] border border-gray-700 rounded-lg px-3 py-2 text-white focus:border-[#00d1ff] focus:outline-none"
                       value={promoChannelId}
                       onChange={handlePromoChannelSelect}
                    >
                       <option value="">-- None (Custom Link) --</option>
                       {channels.map(c => (
                          <option key={c.id} value={c.id}>{c.name}</option>
                       ))}
                    </select>
                    <p className="text-[10px] text-gray-500 mt-1">Selecting a channel will link the banner directly to the player.</p>
                 </div>

                 <div>
                    <label className="text-xs text-gray-400 uppercase font-semibold block mb-1">Title</label>
                    <input 
                       className="w-full bg-[#0f1113] border border-gray-700 rounded-lg px-3 py-2 text-white focus:border-[#00d1ff] focus:outline-none"
                       placeholder="e.g. Exclusive Premiere"
                       value={promoTitle}
                       onChange={e => setPromoTitle(e.target.value)}
                    />
                 </div>
                 <div>
                    <label className="text-xs text-gray-400 uppercase font-semibold block mb-1">Image URL or Upload</label>
                    <div className="flex gap-2">
                       <div className="relative flex-1">
                          <ImageIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 w-4 h-4" />
                          <input 
                             className="w-full bg-[#0f1113] border border-gray-700 rounded-lg py-2 pl-9 pr-3 text-white focus:border-[#00d1ff] focus:outline-none font-mono text-xs"
                             placeholder="https://..."
                             value={promoImg}
                             onChange={e => setPromoImg(e.target.value)}
                          />
                       </div>
                       <label className="bg-gray-700 hover:bg-gray-600 text-white rounded-lg px-3 py-2 cursor-pointer transition-colors flex items-center justify-center">
                          <Upload size={18} />
                          <input type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, setPromoImg)} />
                       </label>
                    </div>
                    {promoImg && (
                       <div className="mt-2 h-20 w-full bg-[#0a0c0e] p-2 rounded border border-gray-800">
                          <img src={promoImg} alt="Preview" className="h-full w-full object-cover rounded" />
                       </div>
                    )}
                 </div>
                 
                 {/* Only show Link input if no channel selected */}
                 {!promoChannelId && (
                    <div className="animate-fade-in">
                        <label className="text-xs text-gray-400 uppercase font-semibold block mb-1">Link URL</label>
                        <div className="relative">
                        <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 w-4 h-4" />
                        <input 
                            className="w-full bg-[#0f1113] border border-gray-700 rounded-lg py-2 pl-9 pr-3 text-white focus:border-[#00d1ff] focus:outline-none font-mono text-xs"
                            placeholder="https://..."
                            value={promoLink}
                            onChange={e => setPromoLink(e.target.value)}
                        />
                        </div>
                    </div>
                 )}

                 {/* Badge Selector */}
                 <div className="bg-[#0a0c0e] p-3 rounded-lg border border-gray-700">
                    <label className="text-xs text-gray-400 uppercase font-semibold block mb-2">Display Badge</label>
                    <select 
                       className="w-full bg-[#0f1113] border border-gray-700 rounded-lg px-3 py-2 text-white focus:border-[#00d1ff] focus:outline-none"
                       value={promoBadge}
                       onChange={(e) => setPromoBadge(e.target.value as any)}
                    >
                       <option value="none">None</option>
                       <option value="live">🔴 LIVE</option>
                       <option value="coming_soon">🟡 COMING SOON</option>
                       <option value="streaming">🟢 STREAMING</option>
                    </select>
                 </div>

                 <button 
                   onClick={handleAddPromo}
                   className="w-full bg-[#00d1ff] hover:bg-[#00b8e6] text-[#0f1113] font-bold py-3 rounded-lg flex items-center justify-center gap-2"
                 >
                   <Plus size={18} /> Add to Carousel
                 </button>
              </div>
           </div>

           {/* List Promos */}
           <div className="bg-[#15181a] rounded-xl border border-gray-800 overflow-hidden">
             <div className="p-4 border-b border-gray-800 bg-[#1a1d21]">
               <h3 className="font-semibold text-gray-300">Active Banners</h3>
             </div>
             <div className="divide-y divide-gray-800 max-h-[500px] overflow-y-auto custom-scrollbar">
                {promos.map((item, index) => {
                   const resolvedLink = item.channelId 
                      ? channels.find(c => c.id === item.channelId)?.link 
                      : item.link;
                   
                   const canPreview = resolvedLink && (resolvedLink.includes('.m3u8') || resolvedLink.includes('youtube') || resolvedLink.includes('mp4'));

                   return (
                   <div key={item.id || index} className="p-4 flex flex-col gap-3 hover:bg-[#1a1d21]">
                      <div className="aspect-[3/1] bg-gray-900 rounded-lg overflow-hidden border border-gray-800 relative group">
                        
                        {previewPromoId === item.id && resolvedLink ? (
                            <div className="absolute inset-0 z-20 bg-black">
                               <VideoPlayer url={resolvedLink} title="Preview" autoPlay={true} streamType="auto" />
                               <button 
                                 type="button"
                                 onClick={() => setPreviewPromoId(null)}
                                 className="absolute top-2 right-2 bg-red-600 hover:bg-red-700 text-white text-[10px] font-bold px-2 py-1 rounded shadow-lg z-50 flex items-center gap-1"
                               >
                                  <Square size={10} fill="currentColor" /> STOP
                               </button>
                            </div>
                        ) : (
                            <>
                                <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover" />
                                
                                {/* Badge Rendering in Admin Preview */}
                                {(item.badge === 'live' || (!item.badge && item.isLive)) && (
                                   <div className="absolute top-2 left-2 bg-red-600 text-white text-[10px] font-bold px-2 py-1 rounded shadow z-10">
                                      WATCH NOW
                                   </div>
                                )}
                                {item.badge === 'coming_soon' && (
                                   <div className="absolute top-2 left-2 bg-yellow-500 text-black text-[10px] font-bold px-2 py-1 rounded shadow z-10">
                                      COMING SOON
                                   </div>
                                )}
                                {item.badge === 'streaming' && (
                                   <div className="absolute top-2 left-2 bg-green-500 text-white text-[10px] font-bold px-2 py-1 rounded shadow z-10">
                                      STREAMING
                                   </div>
                                )}
                                
                                {/* Overlay Delete Button */}
                                <button
                                    type="button"
                                    onClick={(e) => handleDeletePromo(e, item.id, index)}
                                    className="absolute top-2 right-2 bg-red-600 text-white p-2 rounded-full shadow-lg z-50 transition-transform hover:scale-110"
                                    title="Delete Banner"
                                >
                                    <Trash2 size={16} />
                                </button>

                                {/* Preview Button */}
                                {canPreview && (
                                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
                                        <button 
                                            type="button"
                                            onClick={() => setPreviewPromoId(item.id)}
                                            className="bg-black/50 hover:bg-[#00d1ff] text-white hover:text-black p-3 rounded-full backdrop-blur-sm transition-all transform hover:scale-110 pointer-events-auto shadow-xl border border-white/20"
                                            title="Click to Preview (5s)"
                                        >
                                            <Play size={24} fill="currentColor" />
                                        </button>
                                    </div>
                                )}
                            </>
                        )}
                      </div>
                      <div className="flex justify-between items-start">
                         <div>
                            <div className="font-bold text-white text-sm">{item.title}</div>
                            <div className="text-xs text-gray-500 truncate max-w-[200px]">
                                {item.channelId ? (
                                    <span className="text-[#00d1ff] flex items-center gap-1"><PlayCircle size={10} /> Linked to Channel</span>
                                ) : (
                                    item.link || 'No link'
                                )}
                            </div>
                         </div>
                         
                         {/* Secondary Delete Button (Always Visible) */}
                         <button 
                            type="button"
                            onClick={(e) => handleDeletePromo(e, item.id, index)}
                            className="p-2 text-gray-500 hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-colors z-20"
                            title="Delete"
                         >
                            <Trash2 size={18} />
                         </button>
                      </div>
                   </div>
                )})}
                {promos.length === 0 && (
                  <div className="p-8 text-center text-gray-500 italic">No banners active. Add one to show on main page.</div>
                )}
             </div>
           </div>
        </div>
      )}

      {/* === NOTIFICATIONS TAB === */}
      {activeTab === 'notifications' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
           <div className="bg-[#15181a] p-6 rounded-xl border border-gray-800 h-fit">
              <h3 className="text-lg font-semibold text-[#00d1ff] mb-4 flex items-center gap-2">
                 <Send size={18} /> Send Push Notification
              </h3>
              <p className="text-gray-400 text-sm mb-4">
                 Send a message to all users. It will appear as a popup when they open the app.
              </p>
              
              <div className="space-y-4">
                 <div>
                    <label className="text-xs text-gray-400 uppercase font-semibold block mb-1">Title</label>
                    <input 
                       className="w-full bg-[#0f1113] border border-gray-700 rounded-lg px-3 py-2 text-white focus:border-[#00d1ff] focus:outline-none"
                       value={notifTitle}
                       onChange={e => setNotifTitle(e.target.value)}
                       placeholder="e.g. New Channels Added!"
                    />
                 </div>
                 <div>
                    <label className="text-xs text-gray-400 uppercase font-semibold block mb-1">Message</label>
                    <textarea 
                       className="w-full bg-[#0f1113] border border-gray-700 rounded-lg px-3 py-2 text-white focus:border-[#00d1ff] focus:outline-none h-32 resize-none"
                       value={notifMsg}
                       onChange={e => setNotifMsg(e.target.value)}
                       placeholder="Enter your announcement details here..."
                    />
                 </div>
                 
                 <button 
                    onClick={handleSendNotification}
                    className="w-full bg-[#00d1ff] hover:bg-[#00b8e6] text-[#0f1113] font-bold py-3 rounded-lg flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(0,209,255,0.3)]"
                 >
                    <Send size={18} /> Send to All Users
                 </button>

                 {notifSuccess && (
                    <div className="bg-green-500/10 border border-green-500/50 text-green-500 px-4 py-2 rounded text-center text-sm animate-fade-in">
                       {notifSuccess}
                    </div>
                 )}
              </div>
           </div>

           <div className="bg-[#15181a] p-6 rounded-xl border border-gray-800 opacity-60 pointer-events-none">
              <div className="flex flex-col items-center justify-center h-full text-center space-y-4 py-10">
                 <Bell size={48} className="text-gray-600" />
                 <h4 className="text-gray-400 font-medium">Notification Preview</h4>
                 <div className="w-full max-w-sm bg-[#1a1d21] border border-[#00d1ff] rounded-lg p-4 shadow-lg text-left relative">
                    <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></div>
                    <h5 className="font-bold text-white text-sm mb-1">{notifTitle || 'Title Preview'}</h5>
                    <p className="text-xs text-gray-400">{notifMsg || 'Message preview will appear here...'}</p>
                 </div>
              </div>
           </div>
        </div>
      )}

      {/* === SETTINGS TAB === */}
      {activeTab === 'settings' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* About Us Content */}
          <div className="bg-[#15181a] p-6 rounded-xl border border-gray-800 h-fit">
            <h3 className="text-lg font-semibold text-[#00d1ff] mb-4">About Us Content</h3>
            <div className="space-y-4">
              <div>
                <label className="text-xs text-gray-400 uppercase font-semibold block mb-1">Content Text</label>
                <textarea 
                  className="w-full bg-[#0f1113] border border-gray-700 rounded-lg px-3 py-2 text-white focus:border-[#00d1ff] focus:outline-none h-64 resize-none leading-relaxed text-sm"
                  value={aboutContent}
                  onChange={e => setAboutContent(e.target.value)}
                  placeholder="Enter the text for the About Us modal..."
                />
                <p className="text-xs text-gray-500 mt-2">
                  Line breaks will be preserved.
                </p>
              </div>
            </div>
          </div>

          {/* Share Settings */}
          <div className="bg-[#15181a] p-6 rounded-xl border border-gray-800 h-fit space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-[#00d1ff] mb-4">Share Configuration</h3>
              <div className="space-y-4">
                <div>
                  <label className="text-xs text-gray-400 uppercase font-semibold block mb-1">Share Title</label>
                  <input 
                    className="w-full bg-[#0f1113] border border-gray-700 rounded-lg px-3 py-2 text-white focus:border-[#00d1ff] focus:outline-none"
                    value={shareTitle}
                    onChange={e => setShareTitle(e.target.value)}
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-400 uppercase font-semibold block mb-1">Share Message</label>
                  <input 
                    className="w-full bg-[#0f1113] border border-gray-700 rounded-lg px-3 py-2 text-white focus:border-[#00d1ff] focus:outline-none"
                    value={shareText}
                    onChange={e => setShareText(e.target.value)}
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-400 uppercase font-semibold block mb-1">Custom Share URL (Optional)</label>
                  <input 
                    className="w-full bg-[#0f1113] border border-gray-700 rounded-lg px-3 py-2 text-white focus:border-[#00d1ff] focus:outline-none font-mono text-sm"
                    value={shareUrl}
                    onChange={e => setShareUrl(e.target.value)}
                    placeholder="Leave empty to use current site URL"
                  />
                </div>
              </div>
            </div>
            
            <div className="pt-4 border-t border-gray-800">
               <h3 className="text-lg font-semibold text-[#00d1ff] mb-4">Ad Settings</h3>
               <div className="flex items-center justify-between bg-[#0f1113] p-3 rounded-lg border border-gray-700">
                 <div>
                    <div className="font-medium text-white">Enable Ads</div>
                    <div className="text-xs text-gray-500">Show AdSense banners across the app</div>
                 </div>
                 <button 
                   onClick={() => setEnableAds(!enableAds)}
                   className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${enableAds ? 'bg-[#00d1ff]' : 'bg-gray-700'}`}
                 >
                   <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${enableAds ? 'translate-x-6' : 'translate-x-1'}`} />
                 </button>
               </div>
            </div>

            <div className="pt-4 border-t border-gray-800">
               <button 
                  onClick={handleSaveSettings}
                  className="w-full bg-[#00d1ff] hover:bg-[#00b8e6] text-[#0f1113] font-bold py-3 rounded-lg flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(0,209,255,0.3)] transition-all"
               >
                  <Save size={18} /> Save All Settings
               </button>

               {settingsSuccess && (
                  <div className="mt-4 bg-green-500/10 border border-green-500/50 text-green-500 px-4 py-2 rounded text-center text-sm flex items-center justify-center gap-2 animate-fade-in">
                     <CheckCircle size={16} /> {settingsSuccess}
                  </div>
               )}
            </div>
            
            {/* Developer Tools / Export */}
            <div className="pt-8 border-t border-gray-800">
               <h3 className="text-lg font-semibold text-white mb-2 flex items-center gap-2">
                 <Code size={18} className="text-yellow-500" /> 
                 Data Export (Developer)
               </h3>
               <p className="text-xs text-gray-400 mb-4">
                 Use this to save your current channels, categories, and settings back into the source code (constants.ts) so they become the permanent defaults.
               </p>
               
               {!generatedCode ? (
                 <button 
                    onClick={generateSourceCode}
                    className="w-full bg-gray-700 hover:bg-gray-600 text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2 transition-colors"
                 >
                    <Code size={18} /> Generate Source Code
                 </button>
               ) : (
                 <div className="animate-fade-in">
                    <div className="relative">
                      <textarea 
                        className="w-full h-40 bg-[#0a0c0e] border border-gray-700 rounded-lg p-3 text-xs font-mono text-gray-300 resize-none focus:outline-none"
                        value={generatedCode}
                        readOnly
                      />
                      <button 
                        onClick={copyToClipboard}
                        className="absolute top-2 right-2 p-2 bg-blue-600 hover:bg-blue-500 text-white rounded shadow-lg transition-colors"
                        title="Copy to Clipboard"
                      >
                        <Copy size={16} />
                      </button>
                    </div>
                    <button 
                      onClick={() => setGeneratedCode('')}
                      className="mt-2 text-xs text-gray-500 hover:text-white underline"
                    >
                      Close Export
                    </button>
                 </div>
               )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export default AdminPanel;
