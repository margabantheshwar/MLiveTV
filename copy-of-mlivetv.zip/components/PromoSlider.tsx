
import React, { useEffect, useRef, useState } from 'react';
import { PromoItem, Channel } from '../types';
import { ExternalLink, Play } from 'lucide-react';

interface PromoSliderProps {
  items: PromoItem[];
  onPlay?: (channel: Channel) => void;
  channels?: Channel[]; // Full list of channels to resolve channelId
}

const PromoSlider: React.FC<PromoSliderProps> = ({ items, onPlay, channels = [] }) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isPaused, setIsPaused] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const activeItems = items.filter(i => i.isActive);

  // Auto-scroll effect
  useEffect(() => {
    if (activeItems.length <= 1) return;

    const interval = setInterval(() => {
      if (!isPaused && scrollRef.current) {
        const container = scrollRef.current;
        const nextIndex = (activeIndex + 1) % activeItems.length;
        scrollToItem(nextIndex);
      }
    }, 4000); 

    return () => clearInterval(interval);
  }, [activeItems.length, isPaused, activeIndex]);

  // Sync active index based on scroll position (Center Detection)
  const handleScroll = () => {
    if (scrollRef.current) {
      const container = scrollRef.current;
      const containerCenter = container.scrollLeft + (container.clientWidth / 2);
      
      let closestIndex = 0;
      let minDistance = Number.MAX_VALUE;

      // Find the child element closest to the center of the container
      Array.from(container.children).forEach((child, index) => {
        const item = child as HTMLElement;
        const itemCenter = item.offsetLeft + (item.offsetWidth / 2);
        const distance = Math.abs(containerCenter - itemCenter);
        
        if (distance < minDistance) {
          minDistance = distance;
          closestIndex = index;
        }
      });

      if (closestIndex !== activeIndex) {
        setActiveIndex(closestIndex);
      }
    }
  };

  const scrollToItem = (index: number) => {
    if (scrollRef.current) {
       const container = scrollRef.current;
       const child = container.children[index] as HTMLElement;
       if (child) {
          // Calculate position to center the item
          const scrollPos = child.offsetLeft - (container.clientWidth / 2) + (child.offsetWidth / 2);
          container.scrollTo({ left: scrollPos, behavior: 'smooth' });
       }
    }
  };

  const handleClick = (item: PromoItem, index: number) => {
    // If clicking a side item, just scroll to it first
    if (index !== activeIndex) {
      scrollToItem(index);
      return;
    }

    // 1. Check if linked to a Channel ID
    if (item.channelId && onPlay) {
        const channel = channels.find(c => c.id === item.channelId);
        if (channel) {
            onPlay(channel);
            return;
        }
    }

    // 2. Fallback: Check if link is provided
    if (item.link) {
        // If it looks like a stream link but no channel ID was set manually
        if (item.link.includes('.m3u8') || item.link.includes('youtube') || item.link.includes('youtu.be')) {
            // Create a temporary channel object
            if (onPlay) {
                onPlay({
                    id: 'temp_promo_' + item.id,
                    name: item.title,
                    link: item.link,
                    logo: item.imageUrl,
                    category: 'promo',
                    streamType: 'auto'
                });
            }
        } else {
            // External link
            window.open(item.link, '_blank');
        }
    }
  };

  if (activeItems.length === 0) return null;

  return (
    <div 
      className="relative group mb-8 animate-fade-in"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onTouchStart={() => setIsPaused(true)}
      onTouchEnd={() => setIsPaused(false)}
    >
      <div 
        ref={scrollRef}
        onScroll={handleScroll}
        className="flex overflow-x-auto gap-4 snap-x snap-mandatory pb-8 pt-4 no-scrollbar px-[15%] md:px-[30%]"
        style={{ scrollBehavior: 'smooth' }}
      >
        {activeItems.map((item, index) => {
          const isActive = index === activeIndex;
          
          return (
            <div
              key={item.id}
              onClick={() => handleClick(item, index)}
              className={`
                flex-shrink-0 relative rounded-xl overflow-hidden shadow-2xl snap-center cursor-pointer
                transition-all duration-500 ease-out
                w-[80vw] md:w-[40vw] lg:w-[30vw]
                ${isActive 
                  ? 'scale-110 opacity-100 z-20 border-2 border-[#00d1ff] shadow-[0_0_30px_rgba(0,209,255,0.3)]' 
                  : 'scale-90 opacity-40 grayscale-[0.7] hover:opacity-60 z-0'
                }
              `}
              style={{ aspectRatio: '16/9' }}
            >
              <img 
                src={item.imageUrl} 
                alt={item.title} 
                className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
                loading="lazy"
              />
              
              {/* Badges - Only show on active */}
              {isActive && (
                <>
                  {(item.badge === 'live' || (!item.badge && item.isLive)) && (
                    <div className="absolute top-3 left-3 z-30 flex items-center gap-2 bg-red-600 text-white text-[10px] md:text-xs font-bold px-2 py-1 rounded shadow-lg animate-pulse">
                      <span className="w-2 h-2 bg-white rounded-full" />
                      LIVE
                    </div>
                  )}
                  {item.badge === 'coming_soon' && (
                    <div className="absolute top-3 left-3 z-30 flex items-center gap-2 bg-yellow-500 text-black text-[10px] md:text-xs font-bold px-2 py-1 rounded shadow-lg">
                      COMING SOON
                    </div>
                  )}
                  {item.badge === 'streaming' && (
                    <div className="absolute top-3 left-3 z-30 flex items-center gap-2 bg-green-500 text-white text-[10px] md:text-xs font-bold px-2 py-1 rounded shadow-lg">
                      <span className="w-2 h-2 bg-white rounded-full animate-pulse" />
                      STREAMING
                    </div>
                  )}
                </>
              )}

              <div className={`absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent flex flex-col justify-end p-4 md:p-6 transition-opacity duration-300 ${isActive ? 'opacity-100' : 'opacity-0'}`}>
                <div className="flex items-center justify-between transform translate-y-0 transition-transform duration-500">
                  <h3 className="text-white font-bold text-lg md:text-xl drop-shadow-md truncate pr-4">
                    {item.title}
                  </h3>
                  {item.channelId ? (
                     <div className="bg-[#00d1ff] p-2 md:p-3 rounded-full text-[#0f1113] shadow-lg hover:scale-110 transition-transform">
                        <Play size={20} fill="currentColor" className="ml-0.5" />
                     </div>
                  ) : item.link && (
                    <div className="bg-white/20 p-2 rounded-full text-white backdrop-blur-md">
                      <ExternalLink size={18} />
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Dots Indicator */}
      {activeItems.length > 1 && (
        <div className="flex justify-center gap-2 -mt-2">
           {activeItems.map((_, idx) => (
              <button 
                 key={idx}
                 onClick={() => scrollToItem(idx)}
                 className={`h-1.5 rounded-full transition-all duration-500 ${activeIndex === idx ? 'w-8 bg-[#00d1ff]' : 'w-2 bg-gray-700 hover:bg-gray-500'}`}
                 aria-label={`Go to slide ${idx + 1}`}
              />
           ))}
        </div>
      )}
    </div>
  );
};

export default PromoSlider;
