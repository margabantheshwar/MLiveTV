
import React, { useEffect, useRef, useState, useCallback } from 'react';
import Hls from 'hls.js';
import { 
  Loader2, 
  AlertCircle, 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize, 
  Minimize, 
  Settings,
  Check,
  Sun
} from 'lucide-react';

interface VideoPlayerProps {
  url: string;
  title: string;
  autoPlay?: boolean;
  streamType?: 'auto' | 'hls' | 'youtube' | 'mp4' | 'iframe';
  backupUrl?: string;
}

interface QualityLevel {
  index: number;
  height: number;
  label: string;
}

interface GestureFeedback {
  type: 'volume' | 'brightness';
  value: number; // 0-1 for volume, 0.5-1.5 for brightness
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({ url, title, autoPlay = true, streamType = 'auto', backupUrl }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  
  // URL State for Failover
  const [currentUrl, setCurrentUrl] = useState(url);
  const [hasRetried, setHasRetried] = useState(false);

  // Player State
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(1);
  const [brightness, setBrightness] = useState(1); // 1 = 100%
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  
  // Gesture State
  const touchStartX = useRef<number>(0);
  const touchStartY = useRef<number>(0);
  const initialValueRef = useRef<number>(0); // Store initial volume/brightness on touch start
  const [gestureFeedback, setGestureFeedback] = useState<GestureFeedback | null>(null);

  // Quality State
  const [qualities, setQualities] = useState<QualityLevel[]>([]);
  const [currentQuality, setCurrentQuality] = useState<number>(-1); // -1 = Auto
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  
  const controlTimeoutRef = useRef<any>(null);

  // Re-detect type if we switched URLs
  const effectiveType = hasRetried ? 'auto' : streamType;
  const isYouTube = effectiveType === 'youtube' || (effectiveType === 'auto' && (currentUrl.includes('youtube.com') || currentUrl.includes('youtu.be')));
  const isIframe = effectiveType === 'iframe';

  // --- Helpers ---

  const getEmbedUrl = (rawUrl: string) => {
    if (rawUrl.includes('embed/')) return rawUrl;
    if (rawUrl.includes('watch?v=')) return rawUrl.replace('watch?v=', 'embed/');
    if (rawUrl.includes('youtu.be/')) return rawUrl.replace('youtu.be/', 'youtube.com/embed/');
    return rawUrl;
  };

  const formatQualityLabel = (height: number) => {
    // Robust mapping for standard resolutions
    if (height >= 2160) return '4K';
    if (height >= 1440) return '2K';
    if (height >= 1080) return '1080p';
    if (height >= 720) return '720p';
    if (height >= 480) return '480p';
    if (height >= 360) return '360p';
    return `${height}p`;
  };

  const handleFailover = useCallback(() => {
    if (backupUrl && !hasRetried) {
      console.warn("Primary stream failed. Switching to backup:", backupUrl);
      setHasRetried(true);
      setCurrentUrl(backupUrl);
      setError(null);
      setLoading(true);
      return true;
    }
    return false;
  }, [backupUrl, hasRetried]);

  // --- Interaction Handlers ---

  const handleMouseMove = () => {
    setShowControls(true);
    if (controlTimeoutRef.current) clearTimeout(controlTimeoutRef.current);
    controlTimeoutRef.current = setTimeout(() => {
      if (isPlaying && !isSettingsOpen) setShowControls(false);
    }, 3000);
  };
  
  // Gesture Handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    if (isYouTube || isIframe) return;
    
    // Ignore if touching controls
    if ((e.target as HTMLElement).closest('button') || (e.target as HTMLElement).closest('input')) {
        return;
    }

    touchStartX.current = e.touches[0].clientX;
    touchStartY.current = e.touches[0].clientY;
    
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const isRightSide = touchStartX.current > rect.left + (rect.width / 2);
    
    // Store initial values
    if (isRightSide) {
        initialValueRef.current = volume;
    } else {
        initialValueRef.current = brightness;
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (isYouTube || isIframe || !containerRef.current) return;
    
    const currentY = e.touches[0].clientY;
    const diffY = touchStartY.current - currentY; // Positive = swipe up
    const rect = containerRef.current.getBoundingClientRect();
    const sensitivity = 0.005; // Adjust sensitivity
    
    const isRightSide = touchStartX.current > rect.left + (rect.width / 2);

    if (Math.abs(diffY) > 10) { // Threshold
        if (isRightSide) {
            // Volume Control (Right Side)
            let newVol = initialValueRef.current + (diffY * sensitivity);
            newVol = Math.max(0, Math.min(1, newVol));
            updateVolume(newVol);
            setGestureFeedback({ type: 'volume', value: newVol });
        } else {
            // Brightness Control (Left Side)
            // Range 0.5 to 1.5
            let newBright = initialValueRef.current + (diffY * sensitivity);
            newBright = Math.max(0.5, Math.min(1.5, newBright));
            setBrightness(newBright);
            setGestureFeedback({ type: 'brightness', value: newBright });
        }
    }
  };

  const handleTouchEnd = () => {
    setGestureFeedback(null);
  };

  // Mobile Tap Handler (Toggle Controls)
  const handleTap = (e: React.MouseEvent) => {
    if (gestureFeedback) return; // Don't toggle if we just swiped

    if ((e.target as HTMLElement).closest('button') || (e.target as HTMLElement).closest('input')) {
        return;
    }

    if (isSettingsOpen) {
        setIsSettingsOpen(false);
        return;
    }

    setShowControls(!showControls);
    if (!showControls) {
         if (controlTimeoutRef.current) clearTimeout(controlTimeoutRef.current);
         controlTimeoutRef.current = setTimeout(() => {
            if (isPlaying) setShowControls(false);
         }, 3000);
    }
  };

  const togglePlay = useCallback(() => {
    if (videoRef.current) {
      if (videoRef.current.paused) {
        videoRef.current.play().catch(e => console.error("Play failed", e));
      } else {
        videoRef.current.pause();
      }
    }
  }, []);

  const toggleMute = useCallback(() => {
    if (videoRef.current) {
      const newMuted = !videoRef.current.muted;
      videoRef.current.muted = newMuted;
      setIsMuted(newMuted);
      if (newMuted) setVolume(0);
      else setVolume(1);
    }
  }, []);

  const updateVolume = useCallback((val: number) => {
      setVolume(val);
      if (videoRef.current) {
          videoRef.current.volume = val;
          videoRef.current.muted = val === 0;
      }
      setIsMuted(val === 0);
  }, []);

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    updateVolume(val);
  };

  const toggleFullscreen = useCallback(async () => {
    if (!containerRef.current) return;
    
    if (!document.fullscreenElement) {
      try {
        await containerRef.current.requestFullscreen();
        setIsFullscreen(true);
      } catch (err) {
        console.error("Error attempting to enable fullscreen:", err);
      }
    } else {
      if (document.exitFullscreen) {
        await document.exitFullscreen();
        setIsFullscreen(false);
      }
    }
  }, []);

  const changeQuality = (levelIndex: number) => {
    setCurrentQuality(levelIndex);
    if (hlsRef.current) {
      hlsRef.current.currentLevel = levelIndex;
    }
    setIsSettingsOpen(false);
  };

  // Keyboard controls handler
  const handleKeyDown = (e: React.KeyboardEvent) => {
    // If user is tabbing through buttons, allow default
    if ((e.target as HTMLElement).tagName === 'BUTTON' || (e.target as HTMLElement).tagName === 'INPUT') {
      return; 
    }
    
    switch(e.key.toLowerCase()) {
      case ' ':
      case 'k':
        e.preventDefault();
        togglePlay();
        break;
      case 'f':
        e.preventDefault();
        toggleFullscreen();
        break;
      case 'm':
        e.preventDefault();
        toggleMute();
        break;
      case 'arrowup':
        e.preventDefault();
        updateVolume(Math.min(1, volume + 0.1));
        break;
      case 'arrowdown':
        e.preventDefault();
        updateVolume(Math.max(0, volume - 0.1));
        break;
      case 'arrowleft':
         e.preventDefault();
         if (videoRef.current) videoRef.current.currentTime -= 10;
         break;
      case 'arrowright':
         e.preventDefault();
         if (videoRef.current) videoRef.current.currentTime += 10;
         break;
    }
  };

  // --- Effects ---

  // Reset state when external URL changes
  useEffect(() => {
    setCurrentUrl(url);
    setHasRetried(false);
    setError(null);
    setLoading(true);
  }, [url]);

  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  useEffect(() => {
    setLoading(true);
    setQualities([]);
    setCurrentQuality(-1);
    // Reset brightness on new video
    setBrightness(1);
    
    if (isYouTube || isIframe) {
      setLoading(false);
      setError(null);
      return; 
    }

    const video = videoRef.current;
    if (!video) return;

    video.volume = volume;
    video.muted = isMuted;

    const onPlay = () => setIsPlaying(true);
    const onPause = () => setIsPlaying(false);
    const onLoaded = () => setLoading(false);
    const onWaiting = () => setLoading(true);
    const onPlaying = () => { setLoading(false); setIsPlaying(true); };
    
    const onError = () => {
      if (handleFailover()) return;

      // Improve error logging to prevent [object Object] confusion
      if (video.error) {
         console.error("Video Error:", { 
             code: video.error.code, 
             message: video.error.message 
         });
         setError("STAY TUNED WITH MLIVETV WE WILL SOON FIX IT");
      } else {
         setError("STAY TUNED WITH MLIVETV WE WILL SOON FIX IT");
      }
      setLoading(false);
    };

    video.addEventListener('play', onPlay);
    video.addEventListener('pause', onPause);
    video.addEventListener('loadeddata', onLoaded);
    video.addEventListener('waiting', onWaiting);
    video.addEventListener('playing', onPlaying);
    video.addEventListener('error', onError);

    // Explicit HLS check or Auto-detect
    const isHls = effectiveType === 'hls' || (effectiveType === 'auto' && currentUrl.includes('.m3u8'));

    if (isHls && Hls.isSupported()) {
      if (hlsRef.current) hlsRef.current.destroy();
      
      const hls = new Hls({
        capLevelToPlayerSize: true,
        autoStartLoad: true,
      });
      hlsRef.current = hls;

      hls.loadSource(currentUrl);
      hls.attachMedia(video);
      
      hls.on(Hls.Events.MANIFEST_PARSED, (event, data) => {
        const levels = data.levels.map((l, idx) => ({
          index: idx,
          height: l.height,
          label: formatQualityLabel(l.height)
        })).sort((a, b) => b.height - a.height);

        setQualities(levels);
        setLoading(false);
        setError(null);
        if (autoPlay) video.play().catch(() => {});
      });

      hls.on(Hls.Events.ERROR, (event, data) => {
        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              if (handleFailover()) {
                  hls.destroy();
                  return;
              }
              // Try to recover network error if no backup
              console.warn("HLS Network Error, attempting to recover...");
              hls.startLoad();
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              if (handleFailover()) {
                  hls.destroy();
                  return;
              }
              console.warn("HLS Media Error, attempting to recover...");
              hls.recoverMediaError();
              break;
            default:
              if (handleFailover()) {
                  hls.destroy();
                  return;
              }
              console.error("HLS Fatal Error:", data);
              hls.destroy();
              setError("STAY TUNED WITH MLIVETV WE WILL SOON FIX IT");
              setLoading(false);
              break;
          }
        }
      });
    } else {
      // Native (MP4)
      video.src = currentUrl;
      video.load();
      if (autoPlay) {
         const playPromise = video.play();
         if (playPromise !== undefined) {
            playPromise.catch(() => {});
         }
      }
    }

    return () => {
      video.removeEventListener('play', onPlay);
      video.removeEventListener('pause', onPause);
      video.removeEventListener('loadeddata', onLoaded);
      video.removeEventListener('waiting', onWaiting);
      video.removeEventListener('playing', onPlaying);
      video.removeEventListener('error', onError);
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
    };
  }, [currentUrl, effectiveType, isYouTube, isIframe, handleFailover]);

  // --- Render ---

  if (isYouTube) {
    return (
      <div className="w-full bg-black md:rounded-xl overflow-hidden shadow-2xl aspect-video relative group">
        <iframe
          src={getEmbedUrl(currentUrl)}
          title={title}
          className="w-full h-full border-none"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
        {hasRetried && (
            <div className="absolute top-0 right-0 bg-yellow-500/80 text-black text-[10px] px-2 py-1 z-50 font-bold pointer-events-none">
                BACKUP STREAM
            </div>
        )}
      </div>
    );
  }

  if (isIframe) {
     return (
      <div className="w-full bg-black md:rounded-xl overflow-hidden shadow-2xl aspect-video relative group">
        <iframe
          src={currentUrl}
          title={title}
          className="w-full h-full border-none"
          allow="autoplay; encrypted-media; fullscreen"
          allowFullScreen
        />
      </div>
    );
  }

  return (
    <div 
      ref={containerRef}
      className="w-full bg-black md:rounded-xl overflow-hidden shadow-2xl relative aspect-video group select-none outline-none ring-offset-2 focus:ring-2 focus:ring-[#00d1ff]"
      onMouseMove={handleMouseMove}
      onMouseLeave={() => isPlaying && setShowControls(false)}
      onDoubleClick={toggleFullscreen}
      onClick={handleTap}
      onKeyDown={handleKeyDown}
      tabIndex={0}
      aria-label={`Video Player for ${title}`}
    >
       {/* Gesture Feedback Overlay */}
       {gestureFeedback && (
          <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/20 pointer-events-none">
             <div className="bg-black/60 backdrop-blur-sm p-4 rounded-xl flex flex-col items-center gap-2">
                 {gestureFeedback.type === 'volume' ? (
                     <>
                        <Volume2 size={32} className="text-[#00d1ff]" />
                        <div className="w-32 h-1.5 bg-gray-600 rounded-full overflow-hidden">
                           <div className="h-full bg-[#00d1ff] transition-all" style={{ width: `${gestureFeedback.value * 100}%` }} />
                        </div>
                        <span className="text-white font-bold text-sm">{Math.round(gestureFeedback.value * 100)}%</span>
                     </>
                 ) : (
                     <>
                        <Sun size={32} className="text-yellow-400" />
                        <div className="w-32 h-1.5 bg-gray-600 rounded-full overflow-hidden">
                           <div className="h-full bg-yellow-400 transition-all" style={{ width: `${(gestureFeedback.value - 0.5) * 100}%` }} />
                        </div>
                        <span className="text-white font-bold text-sm">{Math.round((gestureFeedback.value - 0.5) * 100)}%</span>
                     </>
                 )}
             </div>
          </div>
       )}

      <div className={`absolute top-0 left-0 right-0 p-4 bg-gradient-to-b from-black/80 to-transparent z-10 transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}>
        <h2 className="text-white font-bold text-lg drop-shadow-md truncate pr-8 flex items-center gap-2">
            {title}
            {hasRetried && <span className="text-[9px] bg-yellow-500 text-black px-1.5 rounded font-bold">BACKUP</span>}
        </h2>
      </div>

      {/* Watermark - Moved to TOP LEFT */}
      <div className="absolute top-3 left-3 sm:top-5 sm:left-5 z-20 pointer-events-none opacity-60 flex items-center gap-1.5 select-none transition-opacity duration-300 drop-shadow-lg">
         <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-lg bg-gradient-to-br from-[#00d1ff] to-blue-600 flex items-center justify-center shadow-[0_0_15px_rgba(0,209,255,0.4)] border border-white/10">
             <span className="font-black text-white text-[10px] sm:text-xs leading-none">M</span>
         </div>
         <span className="font-bold text-white text-xs sm:text-sm tracking-tight drop-shadow-md">
           MLive<span className="text-[#00d1ff]">TV</span>
         </span>
      </div>

      {loading && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 backdrop-blur-sm z-30 pointer-events-none transition-all duration-300">
          <div className="relative flex items-center justify-center mb-4">
             {/* Custom Spinner */}
             <div className="w-14 h-14 border-4 border-[#00d1ff]/20 border-t-[#00d1ff] rounded-full animate-spin"></div>
             <div className="absolute w-10 h-10 border-4 border-white/10 border-b-white rounded-full animate-spin-reverse" style={{ animationDirection: 'reverse', animationDuration: '1s' }}></div>
             <Play className="absolute w-5 h-5 text-[#00d1ff] fill-[#00d1ff] animate-pulse" />
          </div>
          <div className="flex flex-col items-center gap-1">
             <span className="text-white font-bold text-lg tracking-widest animate-pulse">BUFFERING...</span>
             <span className="text-[#00d1ff] text-xs font-mono tracking-wide">Loading Stream...</span>
          </div>
        </div>
      )}

      {error && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-900 z-30 text-center p-4">
          <AlertCircle className="w-12 h-12 text-red-500 mb-2" />
          <p className="text-gray-300 text-sm font-bold animate-pulse">{error}</p>
        </div>
      )}

      {/* Video Element with Touch Handlers Overlay */}
      <div 
        className="relative w-full h-full"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        // Important: prevents scrolling while swiping on video on some browsers
        style={{ touchAction: 'none' }}
      >
        <video
          ref={videoRef}
          className="w-full h-full object-contain cursor-pointer"
          playsInline
          crossOrigin="anonymous" 
          style={{ filter: `brightness(${brightness})` }}
        />
      </div>

      {(!isPlaying || showControls) && !loading && !error && !gestureFeedback && (
        <div className="absolute inset-0 flex items-center justify-center z-10 pointer-events-none">
          <div className={`bg-black/40 backdrop-blur-sm p-4 rounded-full border border-white/20 shadow-xl transition-opacity duration-300 ${isPlaying ? 'opacity-0 md:opacity-0' : 'opacity-100'}`}>
             {isPlaying ? <Pause className="w-10 h-10 text-white fill-white" /> : <Play className="w-10 h-10 text-white fill-white translate-x-1" />}
          </div>
        </div>
      )}

      <div 
        className={`absolute bottom-0 left-0 right-0 px-4 pb-4 pt-12 bg-gradient-to-t from-black/90 via-black/60 to-transparent z-20 transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}
        onClick={(e) => e.stopPropagation()} 
      >
        <div className="flex items-center gap-4">
          
          <button 
             onClick={togglePlay} 
             className="text-white hover:text-[#00d1ff] transition-colors focus:outline-none focus:ring-2 focus:ring-[#00d1ff] rounded p-1"
             aria-label={isPlaying ? "Pause" : "Play"}
          >
            {isPlaying ? <Pause size={28} fill="currentColor" /> : <Play size={28} fill="currentColor" />}
          </button>

          {/* Volume Control - Always visible */}
          <div className="flex items-center gap-2">
            <button 
                onClick={toggleMute} 
                className="text-white hover:text-[#00d1ff] transition-colors focus:outline-none focus:ring-2 focus:ring-[#00d1ff] rounded p-1"
                aria-label={isMuted ? "Unmute" : "Mute"}
            >
              {isMuted || volume === 0 ? <VolumeX size={24} /> : <Volume2 size={24} />}
            </button>
            <div className="w-20 md:w-24 flex items-center">
              <input 
                type="range" 
                min="0" 
                max="1" 
                step="0.05" 
                value={isMuted ? 0 : volume}
                onChange={handleVolumeChange}
                className="w-full h-1 bg-gray-600 rounded-lg appearance-none cursor-pointer accent-[#00d1ff] focus:outline-none focus:ring-2 focus:ring-[#00d1ff]" 
                aria-label="Volume Control"
              />
            </div>
          </div>

          <div className="flex items-center gap-2 px-2 py-1 bg-red-600/20 rounded border border-red-500/30 ml-2">
            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
            <span className="text-red-500 text-[10px] md:text-xs font-bold tracking-wider">LIVE</span>
          </div>

          <div className="flex-1" />

          {/* Quality Settings - Only show if qualities detected (HLS) */}
          {qualities.length > 0 && (
            <div className="relative">
                <button 
                onClick={(e) => { e.stopPropagation(); setIsSettingsOpen(!isSettingsOpen); }}
                className={`text-white transition-colors p-2 rounded-full hover:bg-white/10 focus:outline-none focus:ring-2 focus:ring-[#00d1ff] ${isSettingsOpen ? 'text-[#00d1ff] rotate-45' : ''}`}
                title="Video Quality"
                aria-label="Video Quality Settings"
                aria-haspopup="true"
                aria-expanded={isSettingsOpen}
                >
                <Settings size={22} />
                </button>
                
                {isSettingsOpen && (
                <div className="absolute bottom-full right-0 mb-2 w-48 bg-[#15181a]/95 backdrop-blur-md border border-gray-700 rounded-lg shadow-xl overflow-hidden animate-fade-in-up">
                    <div className="px-4 py-2 border-b border-gray-700 bg-white/5">
                        <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Quality</span>
                    </div>
                    <div className="max-h-60 overflow-y-auto custom-scrollbar">
                        <button 
                            onClick={() => changeQuality(-1)}
                            className="w-full text-left px-4 py-2.5 text-sm hover:bg-[#00d1ff]/20 text-gray-200 hover:text-white flex items-center justify-between transition-colors focus:outline-none focus:bg-[#00d1ff]/20"
                        >
                            <span>Auto</span>
                            {currentQuality === -1 && <Check size={14} className="text-[#00d1ff]" />}
                        </button>
                        {qualities.map((q) => (
                            <button
                                key={q.index}
                                onClick={() => changeQuality(q.index)}
                                className="w-full text-left px-4 py-2.5 text-sm hover:bg-[#00d1ff]/20 text-gray-200 hover:text-white flex items-center justify-between transition-colors focus:outline-none focus:bg-[#00d1ff]/20"
                            >
                                <span>{q.label}</span>
                                {currentQuality === q.index && <Check size={14} className="text-[#00d1ff]" />}
                            </button>
                        ))}
                    </div>
                </div>
                )}
            </div>
          )}

          <button 
             onClick={toggleFullscreen} 
             className="text-white hover:text-[#00d1ff] transition-colors p-2 rounded-full hover:bg-white/10 focus:outline-none focus:ring-2 focus:ring-[#00d1ff]"
             aria-label={isFullscreen ? "Exit Fullscreen" : "Enter Fullscreen"}
          >
            {isFullscreen ? <Minimize size={22} /> : <Maximize size={22} />}
          </button>
          
        </div>
      </div>
    </div>
  );
};

export default VideoPlayer;
