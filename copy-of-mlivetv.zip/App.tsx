

import React, { useState, useEffect, useRef } from 'react';
import { 
  Menu, 
  X, 
  Settings, 
  Share2, 
  Info, 
  Play,
  Search,
  ExternalLink,
  ArrowLeft,
  Bell,
  Heart,
  RefreshCw,
  History,
  Trash2
} from 'lucide-react';
import { Channel, CategoryItem, Notification, AppSettings, PromoItem } from './types';
import { 
  loadChannels, 
  saveChannels, 
  loadCategories, 
  saveCategories, 
  loadSettings, 
  saveSettings,
  getLatestNotification,
  loadPromos,
  savePromos,
  loadFavorites,
  toggleFavorite,
  loadHistory,
  addToHistory,
  clearHistory
} from './services/storageService';
import { 
  DEFAULT_SETTINGS,
  STORAGE_KEY,
  CATEGORIES_KEY,
  NOTIFICATIONS_KEY,
  PROMOS_KEY,
  SETTINGS_KEY 
} from './constants';
import VideoPlayer from './components/VideoPlayer';
import AdminPanel from './components/AdminPanel';
import AboutModal from './components/AboutModal';
import AdBanner from './components/AdBanner';
import PromoSlider from './components/PromoSlider';

function App() {
  const [channels, setChannels] = useState<Channel[]>([]);
  const [categories, setCategories] = useState<CategoryItem[]>([]);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [promos, setPromos] = useState<PromoItem[]>([]);
  const [favoriteIds, setFavoriteIds] = useState<string[]>([]);
  const [historyIds, setHistoryIds] = useState<string[]>([]);
  
  const [currentCategory, setCurrentCategory] = useState<string>('all');
  const [selectedChannel, setSelectedChannel] = useState<Channel | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [view, setView] = useState<'user' | 'admin'>('user');
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isMobileSearchOpen, setIsMobileSearchOpen] = useState(false);
  
  // Notification State
  const [notification, setNotification] = useState<Notification | null>(null);
  const [showNotification, setShowNotification] = useState(false);

  // Refs
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Initial Load
  useEffect(() => {
    setChannels(loadChannels());
    setCategories(loadCategories());
    setSettings(loadSettings());
    setPromos(loadPromos());
    setFavoriteIds(loadFavorites());
    setHistoryIds(loadHistory());

    // Check for notifications
    const latest = getLatestNotification();
    if (latest) {
      const lastSeenId = localStorage.getItem('last_seen_notification_id');
      if (lastSeenId !== latest.id) {
        setNotification(latest);
        setShowNotification(true);
      }
    }
  }, []);

  // Handle System Back Button (PopState)
  useEffect(() => {
    const handlePopState = (event: PopStateEvent) => {
      // Prioritize closing the most "top-level" overlay
      if (selectedChannel) {
        setSelectedChannel(null);
      } else if (view === 'admin') {
        setView('user');
      } else if (isAboutOpen) {
        setIsAboutOpen(false);
      } else if (isSidebarOpen) {
        setIsSidebarOpen(false);
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [selectedChannel, view, isAboutOpen, isSidebarOpen]);

  // Keyboard shortcut for search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Focus search on '/'
      if (e.key === '/' && !isMobileSearchOpen && view === 'user' && !selectedChannel) {
        if (document.activeElement?.tagName !== 'INPUT' && document.activeElement?.tagName !== 'TEXTAREA') {
          e.preventDefault();
          searchInputRef.current?.focus();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isMobileSearchOpen, view, selectedChannel]);

  // Helpers
  const handleUpdateChannels = (newChannels: Channel[]) => {
    setChannels(newChannels);
    saveChannels(newChannels);
  };

  const handleUpdateCategories = (newCategories: CategoryItem[]) => {
    setCategories(newCategories);
    saveCategories(newCategories);
  };

  const handleUpdatePromos = (newPromos: PromoItem[]) => {
    setPromos(newPromos);
    savePromos(newPromos);
  };

  const handleUpdateSettings = (newSettings: AppSettings) => {
    setSettings(newSettings);
    saveSettings(newSettings);
  };

  const closeNotification = () => {
    if (notification) {
      localStorage.setItem('last_seen_notification_id', notification.id);
    }
    setShowNotification(false);
  };

  const handleToggleFavorite = (e: React.MouseEvent, id: string) => {
    e.stopPropagation(); // Prevent opening channel
    const newFavs = toggleFavorite(id, favoriteIds);
    setFavoriteIds(newFavs);
  };

  const handleShare = async () => {
    const shareData = {
      title: settings.shareTitle,
      text: settings.shareText,
      url: settings.shareUrl || window.location.href,
    };
    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        console.error('Share failed', err);
      }
    } else {
      navigator.clipboard.writeText(shareData.url);
      alert('Link copied to clipboard!');
    }
  };

  const handleRefresh = () => {
    if (window.confirm("Load latest updates? This will refresh the channel list from the server. Your favorites will be saved.")) {
      // Clear specific keys to force reload from constants.ts defaults
      localStorage.removeItem(STORAGE_KEY);
      localStorage.removeItem(CATEGORIES_KEY);
      localStorage.removeItem(PROMOS_KEY);
      localStorage.removeItem(SETTINGS_KEY);
      localStorage.removeItem(NOTIFICATIONS_KEY);
      // We do NOT clear FAVORITES_KEY
      
      window.location.reload();
    }
  };

  const handleAddToHistory = (id: string) => {
     const newHist = addToHistory(id, historyIds);
     setHistoryIds(newHist);
  };
  
  const handleClearHistory = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    // Instant clear without confirmation for better UX
    clearHistory();
    setHistoryIds([]);
  };

  // UI Navigation Logic with History Support
  
  const handleChannelClick = (channel: Channel) => {
    handleAddToHistory(channel.id);
    window.history.pushState({ modal: 'player' }, '');
    
    // Only scroll to top if we are opening the player for the first time.
    // If a channel is already selected (player is sticky), we stay put so user can browse.
    if (!selectedChannel && window.innerWidth < 1024) {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    
    setSelectedChannel(channel);
  };

  const handlePromoClick = (channel: Channel) => {
      // If temporary promo channel, don't add to history
      if (!channel.id.startsWith('temp_promo_')) {
          handleAddToHistory(channel.id);
      }
      window.history.pushState({ modal: 'player' }, '');
      
      // Same logic as handleChannelClick - only scroll if opening from scratch
      if (!selectedChannel && window.innerWidth < 1024) {
          window.scrollTo({ top: 0, behavior: 'smooth' });
      }

      setSelectedChannel(channel);
  };

  const handleAdminOpen = () => {
    window.history.pushState({ view: 'admin' }, '');
    setView('admin');
  };

  const handleSidebarOpen = () => {
    window.history.pushState({ overlay: 'sidebar' }, '');
    setIsSidebarOpen(true);
  };

  const handleAboutOpen = () => {
    window.history.pushState({ overlay: 'about' }, '');
    setIsAboutOpen(true);
    setIsSidebarOpen(false); // Close sidebar if open (don't pop history for sidebar, just replace state conceptually)
  };

  // Generic Back Handler (Replaces UI close buttons)
  const handleBack = () => {
    // If we have an active modal/view that we pushed to history, go back
    if (selectedChannel || view === 'admin' || isAboutOpen || isSidebarOpen) {
      window.history.back();
    }
  };

  const filteredChannels = channels.filter(c => {
    let matchesCategory = true;
    if (currentCategory === 'favorites') {
      matchesCategory = favoriteIds.includes(c.id);
    } else if (currentCategory !== 'all') {
      matchesCategory = c.category === currentCategory;
    }
    const matchesSearch = c.name.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Get recently watched channels object list
  const recentlyWatchedChannels = historyIds
    .map(id => channels.find(c => c.id === id))
    .filter((c): c is Channel => !!c);

  // Check if channel is new (added in last 48 hours)
  const isNewChannel = (createdAt?: number) => {
    if (!createdAt) return false;
    const TWO_DAYS_MS = 48 * 60 * 60 * 1000;
    return Date.now() - createdAt < TWO_DAYS_MS;
  };

  // Navigation Logic
  const isMainPage = !selectedChannel && view === 'user';

  // --- Browser View for Movie Downloads ---
  if (selectedChannel && selectedChannel.category === 'movie') {
    return (
      <div className="fixed inset-0 z-[60] bg-[#0f1113] flex flex-col animate-fade-in">
        <header className="flex items-center justify-between px-4 py-3 bg-[#15181a] border-b border-gray-800 shadow-md relative z-10">
          <button 
            onClick={handleBack}
            className="flex items-center gap-2 px-3 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-lg transition-colors group focus:outline-none focus:ring-2 focus:ring-[#00d1ff]"
            aria-label="Go Back"
          >
            <ArrowLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
            <span className="font-medium">Back</span>
          </button>
          
          <div className="flex-1 text-center px-4 overflow-hidden">
            <h2 className="text-white font-bold truncate text-sm md:text-base">{selectedChannel.name}</h2>
            <div className="text-xs text-[#00d1ff] flex items-center justify-center gap-1 opacity-80">
               Movie Download Page
            </div>
          </div>

          <a 
             href={selectedChannel.link}
             target="_blank"
             rel="noreferrer"
             className="p-2 text-gray-400 hover:text-[#00d1ff] transition-colors rounded-lg hover:bg-white/5 focus:outline-none focus:ring-2 focus:ring-[#00d1ff]"
             title="Open in new tab"
             aria-label="Open in new tab"
          >
             <ExternalLink size={20} />
          </a>
        </header>
        <div className="flex-1 relative bg-white">
           <iframe 
             src={selectedChannel.link} 
             className="absolute inset-0 w-full h-full border-0"
             title={selectedChannel.name}
             sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-modals"
           />
        </div>
        {settings.enableAds && (
          <div className="bg-[#0f1113] border-t border-gray-800 pb-safe">
             <AdBanner className="my-0 border-none rounded-none" />
          </div>
        )}
      </div>
    );
  }

  // --- Main App Render ---
  return (
    <div className="min-h-screen flex flex-col bg-[#0f1113] text-gray-100 font-sans selection:bg-[#00d1ff] selection:text-black">
      
      {/* Notification Toast */}
      {showNotification && notification && (
        <div className="fixed top-20 right-4 z-[70] max-w-sm w-[90%] md:w-full bg-[#15181a] border-l-4 border-[#00d1ff] shadow-2xl rounded-lg p-4 animate-slide-left">
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-3">
              <div className="bg-[#00d1ff]/10 p-2 rounded-full mt-0.5 flex-shrink-0">
                <Bell size={20} className="text-[#00d1ff]" />
              </div>
              <div>
                <h4 className="text-white font-bold text-sm">{notification.title}</h4>
                <p className="text-gray-400 text-xs mt-1 leading-relaxed">{notification.message}</p>
              </div>
            </div>
            <button onClick={closeNotification} className="text-gray-500 hover:text-white transition-colors p-1" aria-label="Close notification">
              <X size={16} />
            </button>
          </div>
        </div>
      )}

      {/* Header - Z-index 50 to stay above player (40) */}
      <header className="sticky top-0 z-[50] bg-[#0f1113]/90 backdrop-blur-md border-b border-white/5 h-16 px-4 md:px-6 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-3">
          {!isMainPage ? (
            <button 
              onClick={handleBack}
              className="p-2 -ml-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition-colors focus:outline-none focus:ring-2 focus:ring-[#00d1ff] group"
              aria-label="Go Back"
            >
              <ArrowLeft size={24} className="group-hover:-translate-x-1 transition-transform" />
            </button>
          ) : (
            <button 
              onClick={handleSidebarOpen}
              className="p-2 -ml-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition-colors focus:outline-none focus:ring-2 focus:ring-[#00d1ff]"
              aria-label="Toggle menu"
            >
              <Menu size={24} />
            </button>
          )}

          {/* Logo - Visible on all screen sizes now */}
          <div className="flex items-center gap-2.5 cursor-pointer group" onClick={() => { if(!isMainPage) handleBack(); }} role="button" tabIndex={0} onKeyDown={(e) => { if(e.key === 'Enter') !isMainPage && handleBack(); }}>
             <div className="w-8 h-8 md:w-9 md:h-9 rounded-lg bg-gradient-to-br from-[#00d1ff] to-blue-600 flex items-center justify-center shadow-[0_0_15px_rgba(0,209,255,0.4)] transform group-hover:scale-105 transition-all duration-300 border border-white/10">
                <span className="font-black text-white text-base md:text-lg tracking-tighter leading-none select-none">M</span>
             </div>
             <h1 className="font-bold text-lg md:text-xl tracking-tight text-white block">
               MLive<span className="text-[#00d1ff]">TV</span>
             </h1>
          </div>
        </div>

        <div className="flex items-center gap-1 sm:gap-3">
           {isMainPage && (
             <>
               {/* Desktop Search */}
               <div className="relative hidden md:block group">
                 <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 w-4 h-4 group-focus-within:text-[#00d1ff] transition-colors" />
                 <input 
                    ref={searchInputRef}
                    type="text" 
                    placeholder="Search channels... (/)" 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="bg-[#15181a] border border-gray-700 rounded-full py-1.5 pl-9 pr-8 text-sm focus:border-[#00d1ff] focus:outline-none w-48 transition-all focus:w-64 text-white placeholder-gray-500"
                    aria-label="Search channels"
                 />
                 {searchTerm && (
                    <button 
                      onClick={() => setSearchTerm('')}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white p-1 rounded-full hover:bg-gray-700/50 transition-colors"
                      title="Clear search"
                      aria-label="Clear search"
                    >
                       <X size={14} />
                    </button>
                 )}
               </div>
               
               {/* Mobile Search Toggle */}
               <button 
                onClick={() => setIsMobileSearchOpen(!isMobileSearchOpen)}
                className={`p-2 rounded-lg transition-colors md:hidden focus:outline-none focus:ring-2 focus:ring-[#00d1ff] ${isMobileSearchOpen ? 'text-[#00d1ff] bg-white/5' : 'text-gray-400 hover:text-white'}`}
                aria-label="Toggle search"
               >
                 <Search size={20} />
               </button>
             </>
           )}

          <button onClick={handleShare} className="p-2 text-gray-400 hover:text-[#00d1ff] transition-colors rounded-lg hover:bg-white/5 focus:outline-none focus:ring-2 focus:ring-[#00d1ff]" title="Share" aria-label="Share">
            <Share2 size={20} />
          </button>
          
          {view !== 'admin' && (
            <button onClick={handleAdminOpen} className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-2 bg-[#15181a] border border-gray-700 text-gray-300 hover:border-gray-500 hover:text-white hidden sm:flex focus:outline-none focus:ring-2 focus:ring-[#00d1ff]">
              <Settings size={16} /> Admin
            </button>
          )}
        </div>
      </header>

      {/* Mobile Search Bar (Expandable) */}
      {isMobileSearchOpen && isMainPage && (
        <div className="md:hidden px-4 py-3 bg-[#15181a] border-b border-gray-800 animate-slide-down sticky top-16 z-[45]">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 w-4 h-4" />
            <input 
              type="text" 
              placeholder="Search channels..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#0f1113] border border-gray-700 rounded-lg py-2 pl-9 pr-10 text-sm focus:border-[#00d1ff] focus:outline-none text-white"
              autoFocus
              aria-label="Search channels mobile"
            />
             {searchTerm && (
                <button 
                  onClick={() => setSearchTerm('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white p-1"
                  aria-label="Clear search"
                >
                  <X size={16} />
                </button>
             )}
          </div>
        </div>
      )}

      {/* Sidebar Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[55] lg:hidden transition-opacity"
          onClick={handleBack}
        />
      )}

      {/* Sidebar - Z-index 60 to be on top of everything */}
      <aside className={`fixed top-0 left-0 bottom-0 w-72 bg-[#15181a] border-r border-white/5 z-[60] transform transition-transform duration-300 ease-in-out pt-20 px-4 shadow-2xl ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <button 
          onClick={handleBack}
          className="absolute top-4 right-4 p-2 text-gray-400 hover:text-white hover:bg-white/5 rounded-lg lg:hidden focus:outline-none focus:ring-2 focus:ring-[#00d1ff]"
          aria-label="Close sidebar"
        >
          <X size={24} />
        </button>

        <div className="overflow-y-auto h-full pb-10 custom-scrollbar">
          <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 px-2">Browse</h3>
          <div className="space-y-1">
            {/* Favorites Category (Injected Manually) */}
            <button
              onClick={() => {
                setCurrentCategory('favorites');
                window.history.back(); 
                setView('user');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={`w-full text-left px-3 py-3 rounded-lg flex items-center justify-between group transition-all focus:outline-none focus:ring-2 focus:ring-[#00d1ff] ${currentCategory === 'favorites' ? 'bg-[#00d1ff]/10 text-[#00d1ff] font-medium' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
            >
              <div className="flex items-center gap-2">
                 <Heart size={18} className={currentCategory === 'favorites' ? 'fill-[#00d1ff]' : ''} />
                 <span>Favorites</span>
              </div>
              {currentCategory === 'favorites' && <div className="w-1.5 h-1.5 rounded-full bg-[#00d1ff]" />}
            </button>

            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => {
                  setCurrentCategory(cat.id);
                  window.history.back();
                  setView('user');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className={`w-full text-left px-3 py-3 rounded-lg flex items-center justify-between group transition-all focus:outline-none focus:ring-2 focus:ring-[#00d1ff] ${currentCategory === cat.id ? 'bg-[#00d1ff]/10 text-[#00d1ff] font-medium' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
              >
                <span>{cat.label}</span>
                {currentCategory === cat.id && <div className="w-1.5 h-1.5 rounded-full bg-[#00d1ff]" />}
              </button>
            ))}
            
            <div className="h-px bg-white/5 my-2 mx-2"></div>
            
            <button 
              onClick={handleAboutOpen}
              className="w-full text-left px-3 py-3 rounded-lg text-gray-400 hover:bg-white/5 hover:text-white flex items-center gap-3 transition-colors focus:outline-none focus:ring-2 focus:ring-[#00d1ff]"
            >
              <Info size={18} /> <span>About Us</span>
            </button>
            <button 
              onClick={handleShare}
              className="w-full text-left px-3 py-3 rounded-lg text-gray-400 hover:bg-white/5 hover:text-white flex items-center gap-3 transition-colors focus:outline-none focus:ring-2 focus:ring-[#00d1ff]"
            >
              <Share2 size={18} /> <span>Share App</span>
            </button>
            <button 
              onClick={() => { handleRefresh(); setIsSidebarOpen(false); }}
              className="w-full text-left px-3 py-3 rounded-lg text-gray-400 hover:bg-white/5 hover:text-white flex items-center gap-3 transition-colors focus:outline-none focus:ring-2 focus:ring-[#00d1ff]"
            >
              <RefreshCw size={18} /> <span>Check for Updates</span>
            </button>
            <button 
               onClick={handleAdminOpen}
               className="w-full text-left px-3 py-3 rounded-lg text-gray-400 hover:bg-white/5 hover:text-white flex items-center gap-3 transition-colors sm:hidden focus:outline-none focus:ring-2 focus:ring-[#00d1ff]"
            >
               <Settings size={18} /> <span>Admin Panel</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-3 md:p-6 lg:p-8 max-w-[1800px] mx-auto w-full transition-all pb-safe relative z-0">
        {view === 'admin' ? (
          <AdminPanel 
            channels={channels}
            categories={categories}
            promos={promos}
            settings={settings}
            onUpdateChannels={handleUpdateChannels}
            onUpdateCategories={handleUpdateCategories}
            onUpdatePromos={handleUpdatePromos}
            onUpdateSettings={handleUpdateSettings}
            onClose={handleBack}
          />
        ) : (
          <div className="space-y-6 animate-fade-in">
            
            {/* Top Ad Banner & Promos - Only show on main page view (without player) or keep above everything? 
                Usually better to keep above. */}
            {isMainPage && (
              <>
                 {settings.enableAds && <AdBanner dataAdFormat="horizontal" className="mt-0" />}
                 {promos.length > 0 && <PromoSlider items={promos} onPlay={handlePromoClick} channels={channels} />}
              </>
            )}

            {/* Split Layout Container */}
            <div className={`flex flex-col ${selectedChannel ? 'lg:flex-row lg:gap-6 lg:items-start' : ''}`}>
               
               {/* LEFT COLUMN: Player (Visible only when channel selected) */}
               {selectedChannel && (
                  <div className="w-full lg:w-[68%] xl:w-[70%] sticky top-16 lg:top-20 z-40 mb-6 lg:mb-0 bg-[#0f1113] pb-2">
                     <div className="bg-[#0f1113] pb-4 rounded-2xl shadow-xl">
                        <div className="bg-[#15181a] rounded-2xl p-0 md:p-4 shadow-2xl border border-gray-800 overflow-hidden">
                           <div className="flex items-center justify-between mb-0 md:mb-4 p-3 md:p-0 bg-[#15181a] md:bg-transparent border-b md:border-none border-gray-800">
                              <div className="flex-1 min-w-0 pr-2">
                                 <h2 className="text-lg md:text-2xl font-bold text-white flex items-center gap-2 truncate">
                                    <span className="w-1.5 h-6 md:w-2 md:h-8 bg-[#00d1ff] rounded-full mr-1 hidden md:block flex-shrink-0"></span>
                                    <span className="truncate">{selectedChannel.name}</span>
                                 </h2>
                                 <p className="text-xs md:text-sm text-gray-400 md:ml-4 mt-0.5 md:mt-1 flex items-center gap-2">
                                    <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse flex-shrink-0"></span>
                                    Live Stream
                                 </p>
                              </div>

                              <div className="flex items-center gap-2">
                                 <button 
                                    onClick={(e) => handleToggleFavorite(e, selectedChannel.id)}
                                    className="p-2 rounded-full bg-gray-800/50 hover:bg-gray-700 text-white transition-colors border border-gray-700/50 hover:border-[#00d1ff]/50 focus:outline-none focus:ring-2 focus:ring-[#00d1ff]"
                                    title="Favorite"
                                 >
                                    <Heart size={20} className={favoriteIds.includes(selectedChannel.id) ? "fill-red-500 text-red-500" : ""} />
                                 </button>
                                 <button 
                                    onClick={handleBack} 
                                    className="text-gray-500 hover:text-white transition-colors p-2 bg-gray-800/50 rounded-full hover:bg-red-500/20 hover:text-red-500 focus:outline-none focus:ring-2 focus:ring-red-500"
                                    title="Close Player"
                                 >
                                    <X size={20} />
                                 </button>
                              </div>
                           </div>
                           <div className="md:rounded-xl overflow-hidden bg-black aspect-video w-full">
                              <VideoPlayer 
                                 url={selectedChannel.link} 
                                 title={selectedChannel.name} 
                                 streamType={selectedChannel.streamType} 
                                 backupUrl={selectedChannel.backupLink}
                              />
                           </div>
                        </div>
                     </div>
                     {settings.enableAds && <AdBanner />}
                  </div>
               )}

               {/* RIGHT COLUMN: Channel Grid & Recents */}
               <div className={`w-full ${selectedChannel ? 'lg:w-[32%] xl:w-[30%] space-y-6' : 'space-y-8'}`}>
                  
                  {/* Recently Watched - Always visible if items exist */}
                  {recentlyWatchedChannels.length > 0 && (
                    <div className="space-y-3">
                       <div className="flex items-center justify-between px-1">
                          <div className="flex items-center gap-2">
                              <History size={18} className="text-[#00d1ff]" />
                              <h2 className="text-lg font-bold text-gray-200">Continue Watching</h2>
                          </div>
                          <button 
                              onClick={handleClearHistory}
                              className="text-xs text-red-500 hover:text-red-400 flex items-center gap-1 transition-colors px-2 py-1 rounded hover:bg-white/5 focus:outline-none focus:ring-2 focus:ring-red-500"
                          >
                              <Trash2 size={12} /> Clear
                          </button>
                       </div>
                       <div className="flex overflow-x-auto gap-3 pb-2 snap-x snap-mandatory no-scrollbar">
                          {recentlyWatchedChannels.map(channel => (
                             <div 
                               key={channel.id}
                               onClick={() => handleChannelClick(channel)}
                               className="flex-shrink-0 w-28 snap-start group relative bg-[#15181a] border border-gray-800 hover:border-gray-700 rounded-xl overflow-hidden cursor-pointer transition-all duration-300 hover:shadow-[0_0_15px_rgba(0,209,255,0.15)] flex flex-col aspect-[210/297]"
                             >
                               <div className="h-[75%] bg-black relative p-1 flex items-center justify-center overflow-hidden border-b border-gray-800/50">
                                  <img 
                                    src={channel.logo} 
                                    alt={channel.name} 
                                    className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-300"
                                  />
                                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 backdrop-blur-[1px]">
                                     <div className="w-8 h-8 rounded-full bg-[#00d1ff] flex items-center justify-center shadow-lg">
                                        <Play size={14} fill="currentColor" className="text-[#0f1113]" />
                                     </div>
                                  </div>
                               </div>
                               <div className="h-[25%] px-1 flex flex-col justify-center bg-[#15181a] text-center">
                                  <h3 className="font-bold text-gray-200 text-[9px] leading-tight truncate w-full group-hover:text-[#00d1ff]">
                                    {channel.name}
                                  </h3>
                               </div>
                             </div>
                          ))}
                       </div>
                    </div>
                  )}

                  {/* Channel Grid */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between px-1">
                      <h2 className="text-lg md:text-xl font-bold text-gray-200">
                        {currentCategory === 'favorites' ? 'Your Favorites' : (
                           currentCategory === 'all' ? 'All Channels' : categories.find(c => c.id === currentCategory)?.label || currentCategory
                        )}
                      </h2>
                      <div className="text-xs md:text-sm text-gray-500">
                        {filteredChannels.length} Channels
                      </div>
                    </div>

                    {filteredChannels.length > 0 ? (
                      <div className={`grid gap-2 md:gap-3 pb-8 ${selectedChannel ? 'grid-cols-3 md:grid-cols-4 lg:grid-cols-2 xl:grid-cols-3' : 'grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8'}`}>
                        {filteredChannels.map(channel => {
                          const isNew = isNewChannel(channel.createdAt);
                          return (
                            <div 
                              key={channel.id}
                              tabIndex={0}
                              role="button"
                              onClick={() => handleChannelClick(channel)}
                              onKeyDown={(e) => {
                                  if (e.key === 'Enter' || e.key === ' ') {
                                      e.preventDefault();
                                      handleChannelClick(channel);
                                  }
                              }}
                              className={`group relative bg-[#15181a] border border-gray-800 hover:border-gray-700 rounded-xl overflow-hidden cursor-pointer transition-all duration-300 hover:shadow-[0_0_20px_rgba(0,209,255,0.15)] flex flex-col aspect-[210/297] focus:outline-none focus:ring-2 focus:ring-[#00d1ff] focus:ring-offset-2 focus:ring-offset-[#15181a] ${selectedChannel?.id === channel.id ? 'ring-2 ring-[#00d1ff]' : ''}`}
                            >
                              <div className="h-[75%] bg-black relative p-1 flex items-center justify-center overflow-hidden border-b border-gray-800/50">
                                <img 
                                  src={channel.logo} 
                                  alt={channel.name} 
                                  className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-300"
                                  loading="lazy"
                                />
                                {isNew && (
                                  <div className="absolute top-0 right-0 z-20 bg-gradient-to-r from-red-600 to-rose-600 text-white text-[9px] font-extrabold px-1.5 py-0.5 rounded-bl-lg shadow-md animate-pulse">
                                    NEW
                                  </div>
                                )}
                                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 backdrop-blur-[1px]">
                                   <div className="w-10 h-10 rounded-full bg-[#00d1ff] flex items-center justify-center shadow-lg transform scale-50 group-hover:scale-100 transition-transform duration-300">
                                      {channel.category === 'movie' ? <ExternalLink size={18} className="text-[#0f1113]" /> : <Play size={18} fill="currentColor" className="text-[#0f1113]" />}
                                   </div>
                                </div>
                              </div>
                              <div className="h-[25%] px-1.5 py-1 flex flex-col justify-center bg-[#15181a] text-center border-t border-gray-800">
                                 <h3 className="font-bold text-gray-200 text-[10px] md:text-xs leading-tight truncate w-full group-hover:text-[#00d1ff] transition-colors">
                                   {channel.name}
                                 </h3>
                                 <div className="text-[9px] text-gray-500 truncate hidden sm:block mt-0.5">
                                    {categories.find(c => c.id === channel.category)?.label}
                                 </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center py-20 text-center opacity-60">
                         <div className="bg-gray-800/50 p-4 rounded-full mb-3">
                            <Search size={32} className="text-gray-500" />
                         </div>
                         <h3 className="text-xl font-bold text-gray-300">No channels found</h3>
                         <p className="text-sm text-gray-500 max-w-xs mx-auto mt-2">
                           Try adjusting your search or category filter.
                         </p>
                      </div>
                    )}
                  </div>
               </div>
            </div>
          </div>
        )}
      </main>

      {/* About Modal */}
      <AboutModal 
        isOpen={isAboutOpen} 
        onClose={handleBack}
        content={settings.aboutContent} 
      />

    </div>
  );
}

export default App;
