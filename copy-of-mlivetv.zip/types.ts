
export interface Channel {
  id: string;
  name: string;
  logo: string;
  link: string;
  backupLink?: string; // Secondary stream if primary fails
  category: string; 
  streamType?: 'auto' | 'hls' | 'youtube' | 'mp4' | 'iframe';
  createdAt?: number;
}

export interface CategoryItem {
  id: string;
  label: string;
  isSystem?: boolean;
}

export interface PromoItem {
  id: string;
  title: string;
  imageUrl: string;
  link: string;
  isActive: boolean;
  isLive?: boolean; 
  badge?: 'live' | 'coming_soon' | 'streaming' | 'none';
  channelId?: string; 
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  timestamp: number;
}

export interface AppSettings {
  aboutContent: string;
  shareTitle: string;
  shareText: string;
  shareUrl: string;
  enableAds: boolean;
}

export interface AdminState {
  isAuthenticated: boolean;
  isEditing: boolean;
  editingId: string | null;
}
